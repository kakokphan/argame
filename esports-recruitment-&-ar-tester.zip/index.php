<?php
/**
 * หน้าแรกและระบบเข้าสู่ระบบ (Login) - index.php
 * สำหรับโครงการคัดเลือกนักกีฬาอีสปอร์ต (Esports Recruitment)
 */

// เริ่มต้น Session เพื่อใช้งานตัวแปรระบบ
session_start();

// นำเข้าไฟล์เชื่อมต่อฐานข้อมูล
require_once 'db_connect.php';

// เคลียร์ข้อความผิดพลาดเดิม
$error_message = "";

// กรณีต้องการออกจากระบบ (Logout)
if (isset($_GET['logout'])) {
    session_destroy();
    header("Location: index.php");
    exit();
}

// เช็กว่าหากผู้ใช้ล็อกอินอยู่แล้ว ให้ข้ามไปยังหน้าเกม AR ทันที
if (isset($_SESSION['user_id'])) {
    header("Location: game.php");
    exit();
}

// ตรวจสอบเมื่อมีการกดปุ่มส่งฟอร์มล็อกอิน
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = trim($_POST['username'] ?? '');
    $password = $_POST['password'] ?? '';

    if (empty($username) || empty($password)) {
        $error_message = "กรุณากรอกชื่อผู้ใช้งานและรหัสผ่านให้ครบถ้วน!";
    } else {
        try {
            // เขียนคิวรีดึงข้อมูลด้วย Prepared Statement เพื่อป้องกัน SQL Injection
            $stmt = $conn->prepare("SELECT * FROM users WHERE username = :username LIMIT 1");
            $stmt->execute([':username' => $username]);
            $user = $stmt->fetch(PDO::FETCH_ASSOC);

            // ตรวจสอบว่าพบผู้ใช้รายนั้นหรือไม่ และตรวจสอบรหัสผ่านที่เข้ารหัสไว้
            if ($user && password_verify($password, $user['password'])) {
                // บันทึกสถานะการเข้าสู่ระบบลงในตัวแปร Session
                $_SESSION['user_id'] = $user['id'];
                $_SESSION['username'] = $user['username'];
                $_SESSION['fullname'] = $user['fullname'];
                $_SESSION['email'] = $user['email'];
                $_SESSION['high_score'] = $user['high_score'];

                // นำทางไปยังหน้าทดสอบสมรรถภาพ (game.php)
                header("Location: game.php");
                exit();
            } else {
                $error_message = "ชื่อผู้ใช้งานหรือรหัสผ่านไม่ถูกต้อง! กรุณาลองใหม่อีกครั้ง";
            }
        } catch (PDOException $e) {
            $error_message = "ระบบฐานข้อมูลขัดข้อง: " . $e->getMessage();
        }
    }
}
?>
<!DOCTYPE html>
<html lang="th" class="dark">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Esports Recruitment - คัดเลือกนักกีฬาอีสปอร์ตหน้าใหม่</title>
    <!-- โหลด Tailwind CSS ผ่าน CDN -->
    <script src="https://cdn.tailwindcss.com"></script>
    <link href="https://fonts.googleapis.com/css2?family=Kanit:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <style>
        body {
            font-family: 'Kanit', sans-serif;
            background-color: #0b0f19;
        }
        /* เอฟเฟกต์แสงไฟเรืองแสงสไตล์นีออน */
        .neon-border {
            box-shadow: 0 0 15px rgba(168, 85, 247, 0.4), inset 0 0 15px rgba(168, 85, 247, 0.2);
        }
        .neon-glow {
            text-shadow: 0 0 10px rgba(168, 85, 247, 0.8), 0 0 20px rgba(236, 72, 153, 0.6);
        }
    </style>
</head>
<body class="text-gray-100 min-h-screen flex flex-col justify-between overflow-x-hidden">

    <!-- แถบเมนูด้านบน (Navigation Bar) -->
    <header class="border-b border-purple-900/40 bg-slate-950/70 backdrop-blur-md sticky top-0 z-50 px-6 py-4">
        <div class="max-w-7xl mx-auto flex justify-between items-center">
            <div class="flex items-center gap-3">
                <span class="text-2xl font-bold bg-gradient-to-r from-purple-500 via-pink-500 to-cyan-400 bg-clip-text text-transparent tracking-wider">
                    NEXUS ESPORTS
                </span>
            </div>
            <div class="text-sm text-purple-300 font-medium tracking-wide border border-purple-500/30 px-3 py-1 rounded bg-purple-950/20">
                RECRUITMENT PLATFORM v2.0
            </div>
        </div>
    </header>

    <!-- พื้นหลังกราฟิกนีออนเรืองแสง -->
    <div class="absolute top-1/4 left-1/4 w-96 h-96 bg-purple-600/10 rounded-full blur-3xl -z-10 pointer-events-none"></div>
    <div class="absolute bottom-1/4 right-1/4 w-96 h-96 bg-pink-600/10 rounded-full blur-3xl -z-10 pointer-events-none"></div>

    <!-- ส่วนเนื้อหาหลัก (Hero Section & Login) -->
    <main class="max-w-7xl mx-auto px-6 py-12 flex-grow flex flex-col lg:flex-row items-center justify-center gap-12 w-full">
        
        <!-- ฝั่งซ้าย: บทความนิยายคัดเลือกนักกีฬาอีสปอร์ต (Esports Lore & Details) -->
        <div class="lg:w-1/2 flex flex-col gap-6 text-center lg:text-left">
            <div class="inline-flex items-center justify-center lg:justify-start gap-2 text-pink-400 font-semibold tracking-widest text-xs uppercase">
                <span class="w-2 h-2 rounded-full bg-pink-500 animate-ping"></span>
                โครงการคัดเลือกนักกีฬาหน้าใหม่ระดับประเทศ
            </div>
            <h1 class="text-4xl md:text-5xl lg:text-6xl font-extrabold tracking-tight leading-tight">
                ปลุกศักยภาพ <span class="bg-gradient-to-r from-purple-400 to-pink-500 bg-clip-text text-transparent neon-glow">แชมป์เปี้ยน</span> ในตัวคุณ!
            </h1>
            <p class="text-gray-400 text-lg leading-relaxed max-w-xl">
                ยินดีต้อนรับสู่ <strong class="text-purple-300">NEXUS ESPORTS Recruitment 2026</strong> โครงการคัดเลือกนักกีฬาอีสปอร์ตหน้าใหม่เพื่อก้าวสู่ระดับมืออาชีพร่วมกับสังกัดชั้นนำของทวีปเอเชีย 
            </p>
            <div class="bg-slate-900/60 border border-purple-900/50 p-6 rounded-2xl backdrop-blur-md flex flex-col gap-3">
                <h3 class="text-purple-300 font-bold text-lg flex items-center gap-2">
                    ⚡ ระบบทดสอบสมรรถภาพและการตอบสนอง AR บนหน้าเว็บ
                </h3>
                <p class="text-sm text-gray-400 leading-relaxed">
                    ไม่ใช่แค่วัดจากประวัติการแข่งขัน! แพลตฟอร์มของเราประมวลผลความสามารถในการตอบสนองทางกายภาพและสมองผ่านการแทรกแซงภาพเสมือนจริง (Augmented Reality) โดยการจับพิกัดปลายนิ้วชี้ของคุณผ่านกล้องเว็บแคม เพื่อประเมินค่า <strong class="text-pink-400">APM (Actions Per Minute)</strong> และ <strong class="text-cyan-400">Reaction Time</strong> เพื่อให้มั่นใจว่าคุณคือสุดยอดผู้เล่นที่คู่ควรกับโอกาสนี้
                </p>
            </div>
        </div>

        <!-- ฝั่งขวา: ฟอร์มล็อกอินเข้าสู่ระบบ -->
        <div class="w-full max-w-md lg:w-1/2">
            <div class="bg-slate-950/80 border border-purple-500/30 rounded-3xl p-8 neon-border backdrop-blur-lg relative overflow-hidden">
                <div class="absolute top-0 left-0 w-full h-1 bg-gradient-to-r from-purple-500 via-pink-500 to-cyan-500"></div>
                
                <h2 class="text-2xl font-bold text-center mb-6 text-white tracking-wide">
                    เข้าสู่ระบบทดสอบฝีมือ
                </h2>

                <!-- แจ้งเตือนข้อผิดพลาด (ถ้ามี) -->
                <?php if (!empty($error_message)): ?>
                    <div class="bg-red-950/60 border border-red-500/50 text-red-200 text-sm p-4 rounded-xl mb-6 flex items-center gap-2">
                        <span>⚠️</span>
                        <span><?php echo htmlspecialchars($error_message); ?></span>
                    </div>
                <?php endif; ?>

                <form action="index.php" method="POST" class="flex flex-col gap-5">
                    
                    <!-- ฟิลด์กรอกชื่อผู้ใช้งาน -->
                    <div class="flex flex-col gap-1">
                        <label for="username" class="text-sm text-gray-400 font-medium">Username (ชื่อผู้ใช้งาน)</label>
                        <input type="text" id="username" name="username" required
                               placeholder="กรอกชื่อผู้ใช้งานที่ลงทะเบียนไว้" 
                               class="w-full px-4 py-3 rounded-xl bg-slate-900 border border-purple-900/60 focus:border-purple-500 focus:ring-2 focus:ring-purple-500/30 outline-none text-white transition-all placeholder:text-gray-600">
                    </div>

                    <!-- ฟิลด์กรอกรหัสผ่าน -->
                    <div class="flex flex-col gap-1">
                        <label for="password" class="text-sm text-gray-400 font-medium">Password (รหัสผ่าน)</label>
                        <input type="password" id="password" name="password" required
                               placeholder="กรอกรหัสผ่านของคุณ" 
                               class="w-full px-4 py-3 rounded-xl bg-slate-900 border border-purple-900/60 focus:border-purple-500 focus:ring-2 focus:ring-purple-500/30 outline-none text-white transition-all placeholder:text-gray-600">
                    </div>

                    <!-- ปุ่มกดเข้าสู่ระบบ -->
                    <button type="submit" 
                            class="w-full mt-2 py-3 bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-500 hover:to-pink-500 text-white font-bold rounded-xl shadow-lg shadow-purple-950/40 hover:shadow-purple-500/20 active:scale-[0.98] transition-all cursor-pointer">
                        ล็อกอินเข้าสู่ระบบ
                    </button>
                </form>

                <div class="relative flex py-4 items-center">
                    <div class="flex-grow border-t border-purple-950"></div>
                    <span class="flex-shrink mx-4 text-xs text-gray-500 uppercase tracking-wider">ยังไม่มีบัญชีนักกีฬา?</span>
                    <div class="flex-grow border-t border-purple-950"></div>
                </div>

                <!-- ปุ่มเปลี่ยนเส้นทางไปยังหน้าลงทะเบียน -->
                <a href="register.php" 
                   class="block text-center w-full py-3 border border-pink-500/40 hover:border-pink-500 text-pink-400 hover:text-pink-300 font-semibold rounded-xl bg-pink-950/10 hover:bg-pink-950/20 transition-all">
                    🎯 ลงทะเบียนนักกีฬาใหม่
                </a>
            </div>
        </div>

    </main>

    <!-- ส่วนท้ายเว็บ (Footer) -->
    <footer class="border-t border-purple-900/20 bg-slate-950 py-6 px-6 text-center text-sm text-gray-500">
        <div class="max-w-7xl mx-auto flex flex-col md:flex-row justify-between items-center gap-4">
            <div>
                © 2026 NEXUS ESPORTS Recruitment. All Rights Reserved.
            </div>
            <div class="flex gap-6 text-xs text-gray-400">
                <a href="#" class="hover:text-purple-400">นโยบายความเป็นส่วนตัว</a>
                <a href="#" class="hover:text-purple-400">ข้อตกลงการคัดเลือก</a>
                <a href="#" class="hover:text-purple-400">ติดต่อคณะกรรมการ</a>
            </div>
        </div>
    </footer>

</body>
</html>
