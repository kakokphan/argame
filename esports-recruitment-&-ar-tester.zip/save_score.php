<?php
/**
 * บันทึกคะแนนผ่าน Fetch API (AJAX) - save_score.php
 * คอยรับคะแนนการทดสอบ AR จากฝั่งผู้เล่นและเปรียบเทียบเพื่ออัปเดตฐานข้อมูล
 */

// เริ่มต้น Session เพื่อยืนยันตัวตนผู้ใช้
session_start();

// กำหนด Header ให้ส่งออกผลลัพธ์เป็นไฟล์ JSON
header('Content-Type: application/json; charset=utf-8');

// นำเข้าไฟล์เชื่อมต่อฐานข้อมูล
require_once 'db_connect.php';

// ตรวจสอบความถูกต้องในการล็อกอินก่อนบันทึกคะแนน
if (!isset($_SESSION['user_id'])) {
    echo json_encode([
        'status' => 'error',
        'message' => 'คุณยังไม่ได้เข้าสู่ระบบ หรือเซสชันหมดอายุ!'
    ]);
    exit();
}

// เช็กว่ารูปแบบการร้องขอข้อมูลต้องเป็นแบบ POST เท่านั้น
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    echo json_encode([
        'status' => 'error',
        'message' => 'รูปแบบการเชื่อมต่อ (Method) ไม่ถูกต้อง!'
    ]);
    exit();
}

// อ่านค่า JSON ที่ส่งมาจากร่างกายของการ Fetch API
$input = json_decode(file_get_contents('php://input'), true);
$score = isset($input['score']) ? intval($input['score']) : 0;
$user_id = $_SESSION['user_id'];

try {
    // ดึงคะแนนปัจจุบันเพื่อเทียบว่าคะแนนใหม่สูงกว่าหรือไม่
    $stmt = $conn->prepare("SELECT high_score FROM users WHERE id = :id LIMIT 1");
    $stmt->execute([':id' => $user_id]);
    $user = $stmt->fetch(PDO::FETCH_ASSOC);

    if ($user) {
        $current_high = intval($user['high_score']);

        // อัปเดตเฉพาะเมื่อคะแนนรอบปัจจุบันสูงกว่าคะแนนสูงสุดเดิมเท่านั้น
        if ($score > $current_high) {
            $update_stmt = $conn->prepare("UPDATE users SET high_score = :score WHERE id = :id");
            $update_stmt->execute([
                ':score' => $score,
                ':id' => $user_id
            ]);

            // อัปเดตข้อมูลคะแนนใหม่ลงตัวแปร Session ไปด้วย
            $_SESSION['high_score'] = $score;

            echo json_encode([
                'status' => 'success',
                'updated' => true,
                'score' => $score,
                'message' => 'ยินดีด้วย! คุณสามารถทำลายสถิติสูงสุดใหม่ได้สำเร็จ'
            ]);
        } else {
            echo json_encode([
                'status' => 'success',
                'updated' => false,
                'score' => $current_high,
                'message' => 'คะแนนครั้งนี้ไม่ทำลายสถิติเดิม คะแนนสูงสุดของคุณยังคงเป็น ' . $current_high
            ]);
        }
    } else {
        echo json_encode([
            'status' => 'error',
            'message' => 'ไม่พบข้อมูลผู้ใช้ในระบบ'
        ]);
    }
} catch (PDOException $e) {
    echo json_encode([
        'status' => 'error',
        'message' => 'เกิดข้อผิดพลาดกับฐานข้อมูล: ' . $e->getMessage()
    ]);
}
?>
