<?php
/**
 * หน้าลงทะเบียนนักกีฬาใหม่ - register.php
 * สำหรับโครงการคัดเลือกนักกีฬาอีสปอร์ต (Esports Recruitment)
 */

// เริ่มต้น Session
session_start();

// นำเข้าไฟล์เชื่อมต่อฐานข้อมูล
require_once 'db_connect.php';

$error_message = "";
$success_flag = false; // ตัวแปรเช็กความสำเร็จสำหรับเปิดกล่องแจ้งเตือน

// ตรวจสอบเมื่อมีการกดส่งฟอร์มสมัครสมาชิก
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $fullname = trim($_POST['fullname'] ?? '');
    $email = trim($_POST['email'] ?? '');
    $game_exp = trim($_POST['game_exp'] ?? '');
    $username = trim($_POST['username'] ?? '');
    $password = $_POST['password'] ?? '';

    // ตรวจสอบค่าว่างเบื้องต้น
    if (empty($fullname) || empty($email) || empty($game_exp) || empty($username) || empty($password)) {
        $error_message = "กรุณากรอกข้อมูลในฟอร์มให้ครบถ้วนทุกฟิลด์!";
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $error_message = "กรุณาระบุรูปแบบอีเมลให้ถูกต้อง!";
    } elseif (strlen($username) < 4) {
        $error_message = "ชื่อผู้ใช้งาน (Username) ต้องมีความยาวอย่างน้อย 4 ตัวอักษร!";
    } elseif (strlen($password) < 6) {
        $error_message = "รหัสผ่าน (Password) ต้องมีความยาวอย่างน้อย 6 ตัวอักษรเพื่อความปลอดภัย!";
    } else {
        try {
            // เช็กก่อนว่ามี Username หรือ Email ซ้ำในระบบหรือไม่
            $check_stmt = $conn->prepare("SELECT id FROM users WHERE username = :username OR email = :email LIMIT 1");
            $check_stmt->execute([':username' => $username, ':email' => $email]);
            
            if ($check_stmt->fetch()) {
                $error_message = "ชื่อผู้ใช้งาน (Username) หรือ อีเมล นี้ถูกใช้ในระบบคัดเลือกไปแล้ว!";
            } else {
                // เข้ารหัสผ่านอย่างปลอดภัยด้วยกลไก BCRYPT ของ PHP (password_hash)
                $hashed_password = password_hash($password, PASSWORD_DEFAULT);

                // แทรกข้อมูลผู้ใช้งานใหม่ลงตาราง users
                $insert_stmt = $conn->prepare("
                    INSERT INTO users (username, password, fullname, email, game_exp, high_score) 
                    VALUES (:username, :password, :fullname, :email, :game_exp, 0)
                ");

                $insert_stmt->execute([
                    ':username' => $username,
                    ':password' => $hashed_password,
                    ':fullname' => $fullname,
                    ':email' => $email,
                    ':game_exp' => $game_exp
                ]);

                // ตั้งค่า Flag สำเร็จเป็น True เพื่อให้แสดงกล่องแจ้งเตือน
                $success_flag = true;
            }
        } catch (PDOException $e) {
            $error_message = "เกิดข้อผิดพลาดในการเชื่อมต่อเพื่อบันทึกข้อมูล: " . $e->getMessage();
        }
    }
}
?>
<!DOCTYPE html>
<html lang="th" class="dark">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>ลงทะเบียนนักกีฬาใหม่ - Esports Recruitment</title>
    <!-- โหลด Tailwind CSS ผ่าน CDN -->
    <script src="https://cdn.tailwindcss.com"></script>
    <link href="https://fonts.googleapis.com/css2?family=Kanit:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <style>
        body {
            font-family: 'Kanit', sans-serif;
            background-color: #0b0f19;
        }
        .neon-border {
            box-shadow: 0 0 15px rgba(236, 72, 153, 0.3), inset 0 0 15px rgba(236, 72, 153, 0.1);
        }
    </style>
</head>
<body class="text-gray-100 min-h-screen flex flex-col justify-between overflow-x-hidden relative">

    <!-- พื้นหลังแสงสว่างนีออน -->
    <div class="absolute top-10 right-10 w-96 h-96 bg-pink-600/10 rounded-full blur-3xl -z-10 pointer-events-none"></div>
    <div class="absolute bottom-10 left-10 w-96 h-96 bg-purple-600/10 rounded-full blur-3xl -z-10 pointer-events-none"></div>

    <!-- แถบเมนูด้านบน -->
    <header class="border-b border-purple-900/40 bg-slate-950/70 backdrop-blur-md sticky top-0 z-50 px-6 py-4">
        <div class="max-w-7xl mx-auto flex justify-between items-center">
            <div class="flex items-center gap-3">
                <a href="index.php" class="text-2xl font-bold bg-gradient-to-r from-purple-500 via-pink-500 to-cyan-400 bg-clip-text text-transparent tracking-wider hover:opacity-90">
                    NEXUS ESPORTS
                </a>
            </div>
            <a href="index.php" class="text-sm text-gray-300 hover:text-white border border-purple-500/20 px-4 py-2 rounded-xl bg-purple-950/10 hover:bg-purple-950/30 transition-all">
                ย้อนกลับหน้าหลัก
            </a>
        </div>
    </header>

    <!-- ส่วนฟอร์มลงทะเบียน -->
    <main class="max-w-xl mx-auto px-6 py-12 flex-grow flex items-center justify-center w-full">
        <div class="w-full bg-slate-950/80 border border-pink-500/30 rounded-3xl p-8 neon-border backdrop-blur-lg relative overflow-hidden">
            <div class="absolute top-0 left-0 w-full h-1 bg-gradient-to-r from-pink-500 to-purple-500"></div>

            <h2 class="text-3xl font-extrabold text-center mb-2 text-white tracking-wide">
                ลงทะเบียนนักกีฬา
            </h2>
            <p class="text-center text-gray-400 text-sm mb-8">
                กรอกข้อมูลประวัติการแข่งเพื่อเข้าร่วมการคัดตัวระดับมืออาชีพ
            </p>

            <!-- แสดงข้อความผิดพลาด -->
            <?php if (!empty($error_message)): ?>
                <div class="bg-red-950/60 border border-red-500/50 text-red-200 text-sm p-4 rounded-xl mb-6 flex items-center gap-2">
                    <span>⚠️</span>
                    <span><?php echo htmlspecialchars($error_message); ?></span>
                </div>
            <?php endif; ?>

            <form action="register.php" method="POST" class="flex flex-col gap-5">
                
                <!-- ชื่อ-นามสกุลจริง -->
                <div class="flex flex-col gap-1">
                    <label for="fullname" class="text-sm text-gray-400 font-medium">ชื่อ - นามสกุลจริง</label>
                    <input type="text" id="fullname" name="fullname" required
                           value="<?php echo htmlspecialchars($fullname ?? ''); ?>"
                           placeholder="เช่น นายมานะ แข่งขันดี" 
                           class="w-full px-4 py-3 rounded-xl bg-slate-900 border border-purple-900/40 focus:border-pink-500 focus:ring-2 focus:ring-pink-500/30 outline-none text-white transition-all placeholder:text-gray-600">
                </div>

                <!-- อีเมลติดต่อ -->
                <div class="flex flex-col gap-1">
                    <label for="email" class="text-sm text-gray-400 font-medium">อีเมลติดต่อ (Email)</label>
                    <input type="email" id="email" name="email" required
                           value="<?php echo htmlspecialchars($email ?? ''); ?>"
                           placeholder="เช่น manapro@gmail.com" 
                           class="w-full px-4 py-3 rounded-xl bg-slate-900 border border-purple-900/40 focus:border-pink-500 focus:ring-2 focus:ring-pink-500/30 outline-none text-white transition-all placeholder:text-gray-600">
                </div>

                <!-- ประสบการณ์แข่ง / ตำแหน่งที่เล่น -->
                <div class="flex flex-col gap-1">
                    <label for="game_exp" class="text-sm text-gray-400 font-medium">ประสบการณ์การแข่ง / ตำแหน่งที่ถนัด / เกมหลักที่เล่น</label>
                    <textarea id="game_exp" name="game_exp" required rows="3"
                              placeholder="ระบุประสบการณ์แข่งของท่าน เช่น เล่นตำแหน่ง Carry เกม RoV, ผ่านการแข่งทัวร์นาเมนต์จังหวัด หรือทีมระดับไหนมาก่อน" 
                              class="w-full px-4 py-3 rounded-xl bg-slate-900 border border-purple-900/40 focus:border-pink-500 focus:ring-2 focus:ring-pink-500/30 outline-none text-white transition-all placeholder:text-gray-600 resize-none"><?php echo htmlspecialchars($game_exp ?? ''); ?></textarea>
                </div>

                <div class="grid grid-cols-1 md:grid-cols-2 gap-4 border-t border-purple-950/50 pt-4">
                    <!-- ตั้งค่าชื่อผู้ใช้งาน -->
                    <div class="flex flex-col gap-1">
                        <label for="username" class="text-sm text-gray-400 font-medium">ตั้ง Username</label>
                        <input type="text" id="username" name="username" required
                               value="<?php echo htmlspecialchars($username ?? ''); ?>"
                               placeholder="สำหรับใช้ล็อกอิน" 
                               class="w-full px-4 py-3 rounded-xl bg-slate-900 border border-purple-900/40 focus:border-pink-500 focus:ring-2 focus:ring-pink-500/30 outline-none text-white transition-all placeholder:text-gray-600">
                    </div>

                    <!-- ตั้งค่ารหัสผ่าน -->
                    <div class="flex flex-col gap-1">
                        <label for="password" class="text-sm text-gray-400 font-medium">ตั้ง Password</label>
                        <input type="password" id="password" name="password" required
                               placeholder="รหัสผ่าน 6 ตัวขึ้นไป" 
                               class="w-full px-4 py-3 rounded-xl bg-slate-900 border border-purple-900/40 focus:border-pink-500 focus:ring-2 focus:ring-pink-500/30 outline-none text-white transition-all placeholder:text-gray-600">
                    </div>
                </div>

                <!-- ปุ่มส่งฟอร์มลงทะเบียน -->
                <button type="submit" 
                        class="w-full mt-4 py-3 bg-gradient-to-r from-pink-600 to-purple-600 hover:from-pink-500 hover:to-purple-500 text-white font-bold rounded-xl shadow-lg shadow-pink-950/40 hover:shadow-pink-500/20 active:scale-[0.98] transition-all cursor-pointer">
                    ยืนยันการลงทะเบียนนักกีฬา
                </button>
            </form>

            <div class="text-center mt-6">
                <span class="text-sm text-gray-400">เป็นสมาชิกแล้วหรือยัง?</span>
                <a href="index.php" class="text-pink-400 font-semibold ml-2 hover:underline">คลิกเพื่อเข้าสู่ระบบ</a>
            </div>
        </div>
    </main>

    <!-- ส่วนแจ้งเตือนสำเร็จ (Success Overlay/Modal) -->
    <?php if ($success_flag): ?>
    <div class="fixed inset-0 bg-black/80 backdrop-blur-sm flex items-center justify-center p-6 z-50 animate-fade-in">
        <div class="w-full max-w-md bg-slate-900 border border-green-500/50 p-8 rounded-3xl text-center shadow-2xl shadow-green-950/20">
            <div class="w-16 h-16 bg-green-950/80 border border-green-500 text-green-400 rounded-full flex items-center justify-center text-3xl mx-auto mb-4">
                ✓
            </div>
            <h3 class="text-2xl font-bold text-white mb-2">ลงทะเบียนสำเร็จ!</h3>
            <p class="text-gray-400 text-sm mb-6">
                ยินดีต้อนรับสู่โครงการ! บัญชีของคุณถูกเปิดใช้งานเรียบร้อยแล้ว กรุณาใช้ Username และ Password ที่ท่านตั้งไว้เพื่อเข้าสู่ระบบการทดสอบสมรรถภาพระดับ AR
            </p>
            <a href="index.php" 
               class="block w-full py-3 bg-gradient-to-r from-green-500 to-emerald-600 hover:from-green-400 hover:to-emerald-500 text-slate-950 font-bold rounded-xl shadow-lg shadow-green-950/50 hover:shadow-green-500/20 transition-all">
                กลับไปยังหน้าล็อกอิน
            </a>
        </div>
    </div>
    <?php endif; ?>

    <!-- ส่วนท้ายเว็บ -->
    <footer class="border-t border-purple-900/20 bg-slate-950 py-6 px-6 text-center text-sm text-gray-500">
        <div class="max-w-7xl mx-auto flex flex-col md:flex-row justify-between items-center gap-4">
            <div>
                © 2026 NEXUS ESPORTS Recruitment. All Rights Reserved.
            </div>
        </div>
    </footer>

</body>
</html>
