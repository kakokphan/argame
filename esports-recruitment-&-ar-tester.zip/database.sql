-- คำสั่งสร้างฐานข้อมูลสำหรับระบบรับสมัครนักกีฬาอีสปอร์ต (Esports Recruitment)
-- ชื่อฐานข้อมูล: esports_db

CREATE DATABASE IF NOT EXISTS `esports_db` DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE `esports_db`;

-- --------------------------------------------------------

--
-- โครงสร้างตาราง `users`
--

CREATE TABLE IF NOT EXISTS `users` (
  `id` INT(11) NOT NULL AUTO_INCREMENT COMMENT 'รหัสผู้ใช้งาน (Primary Key)',
  `username` VARCHAR(50) NOT NULL UNIQUE COMMENT 'ชื่อผู้ใช้งานสำหรับเข้าสู่ระบบ',
  `password` VARCHAR(255) NOT NULL COMMENT 'รหัสผ่านที่เข้ารหัสด้วย password_hash()',
  `fullname` VARCHAR(100) NOT NULL COMMENT 'ชื่อ-นามสกุลจริงของนักกีฬา',
  `email` VARCHAR(100) NOT NULL UNIQUE COMMENT 'อีเมลสำหรับติดต่อกลับ',
  `game_exp` TEXT NOT NULL COMMENT 'ประสบการณ์แข่งและตำแหน่งที่เล่นในเกม',
  `high_score` INT(11) DEFAULT 0 COMMENT 'คะแนนสูงสุดที่ทำได้ในระบบทดสอบ AR',
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP COMMENT 'วันที่ลงทะเบียนสมัครสมาชิก',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- แทรกข้อมูลจำลองเพื่อความสะดวกในการทดสอบเบื้องต้น
-- รหัสผ่านเริ่มต้นคือ: 123456 (เข้ารหัสด้วย PASSWORD_DEFAULT)
INSERT INTO `users` (`username`, `password`, `fullname`, `email`, `game_exp`, `high_score`) 
VALUES 
('proplayer1', '$2y$10$O6O86qFhV.1uI4Fz9/pEwOhB.u26V7N8WOnGgZg850oYpMbyPZtK2', 'อนาวิล สายฟ้า', 'proplayer1@esports.com', 'ประสบการณ์แข่ง RoV Pro League Season 10 ตำแหน่ง Carry / Solo Lane', 15),
('ninja_fps', '$2y$10$O6O86qFhV.1uI4Fz9/pEwOhB.u26V7N8WOnGgZg850oYpMbyPZtK2', 'ศรุต พันธุ์ตา', 'ninja_fps@esports.com', 'ประสบการณ์แข่ง Valorant Challengers Thailand ตำแหน่ง Duelist / Jett main', 22);
