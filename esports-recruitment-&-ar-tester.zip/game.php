<?php
/**
 * หน้าเกมทดสอบสมรรถภาพ AR Hand Tracking - game.php
 * ปลุกศักยภาพอีสปอร์ตด้วยเทคโนโลยีตรวจจับความเคลื่อนไหวด้วยกล้องเว็บแคม
 */

// เริ่มต้น Session
session_start();

// นำเข้าไฟล์เชื่อมต่อฐานข้อมูล เพื่อดึงคะแนนล่าสุดเสมอ
require_once 'db_connect.php';

// ตรวจสอบความถูกต้องของการล็อกอิน หากยังไม่มี Session ให้เด้งกลับหน้า index.php
if (!isset($_SESSION['user_id'])) {
    header("Location: index.php");
    exit();
}

$user_id = $_SESSION['user_id'];
$fullname = $_SESSION['fullname'];
$username = $_SESSION['username'];
$high_score = 0;

// โหลดคะแนนล่าสุดจากฐานข้อมูลเพื่อความสดใหม่
try {
    $stmt = $conn->prepare("SELECT high_score FROM users WHERE id = :id LIMIT 1");
    $stmt->execute([':id' => $user_id]);
    $user = $stmt->fetch(PDO::FETCH_ASSOC);
    if ($user) {
        $high_score = intval($user['high_score']);
        $_SESSION['high_score'] = $high_score; // อัปเดตตัวแปร Session
    }
} catch (PDOException $e) {
    // หากฐานข้อมูลมีข้อผิดพลาด ให้ดึงจาก Session เดิมไปก่อน
    $high_score = isset($_SESSION['high_score']) ? intval($_SESSION['high_score']) : 0;
}
?>
<!DOCTYPE html>
<html lang="th" class="dark">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>AR Reflex Testing Stage - NEXUS ESPORTS</title>
    <!-- โหลด Tailwind CSS และ Lucide Icons -->
    <script src="https://cdn.tailwindcss.com"></script>
    <link href="https://fonts.googleapis.com/css2?family=Kanit:wght@300;400;500;600;700&family=JetBrains+Mono:wght@400;700&display=swap" rel="stylesheet">
    
    <!-- โหลด MediaPipe Hands และ Camera Utils ไลบรารีจับจุดพิกัดมือผ่านกล้อง -->
    <script src="https://cdn.jsdelivr.net/npm/@mediapipe/camera_utils/camera_utils.js" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/@mediapipe/hands/hands.js" crossorigin="anonymous"></script>

    <style>
        body {
            font-family: 'Kanit', sans-serif;
            background-color: #080c14;
        }
        .mono-font {
            font-family: 'JetBrains Mono', monospace;
        }
        .game-border {
            box-shadow: 0 0 25px rgba(139, 92, 246, 0.3);
        }
        /* พลิกกระจกกล้องเพื่อให้ผู้เล่นมองตัวเองแล้วไม่งงขวา-ซ้าย */
        #webcam {
            transform: scaleX(-1);
        }
    </style>
</head>
<body class="text-gray-100 min-h-screen flex flex-col justify-between overflow-x-hidden">

    <!-- แถบเมนูด้านบน -->
    <header class="border-b border-purple-900/40 bg-slate-950/70 backdrop-blur-md sticky top-0 z-50 px-6 py-4">
        <div class="max-w-7xl mx-auto flex justify-between items-center">
            <div class="flex items-center gap-3">
                <span class="text-xl font-bold bg-gradient-to-r from-purple-500 via-pink-500 to-cyan-400 bg-clip-text text-transparent tracking-wider">
                    NEXUS AR ARENA
                </span>
            </div>
            
            <div class="flex items-center gap-4">
                <!-- ข้อมูลผู้ใช้งานที่ล็อกอินปัจจุบัน -->
                <div class="hidden sm:flex flex-col items-end text-xs">
                    <span class="text-gray-400">เข้าสู่ระบบในชื่อ</span>
                    <span class="text-purple-300 font-bold"><?php echo htmlspecialchars($fullname); ?> (<?php echo htmlspecialchars($username); ?>)</span>
                </div>
                <!-- ปุ่มออกจากระบบ -->
                <a href="index.php?logout=1" 
                   class="px-4 py-2 bg-red-950/40 hover:bg-red-900/50 text-red-400 border border-red-900/40 hover:border-red-500/50 rounded-xl text-xs font-semibold transition-all">
                    ออกจากระบบ
                </a>
            </div>
        </div>
    </header>

    <!-- พื้นหลังแสงเรืองแสง -->
    <div class="absolute top-1/3 left-10 w-96 h-96 bg-purple-600/5 rounded-full blur-3xl -z-10 pointer-events-none"></div>
    <div class="absolute bottom-1/3 right-10 w-96 h-96 bg-cyan-600/5 rounded-full blur-3xl -z-10 pointer-events-none"></div>

    <main class="max-w-7xl mx-auto px-6 py-8 flex-grow w-full flex flex-col lg:flex-row gap-8 items-start justify-center">
        
        <!-- ส่วนซ้าย: กล้องเว็บแคม และจอเกม Canvas -->
        <div class="w-full lg:w-2/3 flex flex-col gap-4">
            
            <!-- แผงหน้าปัดเกม แสดงผู้เล่นและสถานะ -->
            <div class="bg-slate-950 border border-purple-900/50 rounded-2xl p-4 flex flex-wrap justify-between items-center gap-4">
                <div class="flex items-center gap-3">
                    <div class="w-3 h-3 bg-green-500 rounded-full animate-ping"></div>
                    <span class="text-sm font-semibold text-gray-300">ระบบทดสอบสมรรถภาพการตอบสนองเสมือนจริง</span>
                </div>
                
                <!-- โหมดการเล่น (สามารถสลับเป็นเมาส์จำลองได้หากกล้องไม่สะดวก) -->
                <div class="flex gap-2 text-xs">
                    <button id="btn-mode-ar" onclick="setPlayMode('ar')" 
                            class="px-3 py-1.5 rounded-lg font-bold bg-purple-600 text-white border border-purple-500 shadow shadow-purple-500/30 transition-all cursor-pointer">
                        📷 โหมดกล้องเว็บแคม (AR)
                    </button>
                    <button id="btn-mode-mouse" onclick="setPlayMode('mouse')" 
                            class="px-3 py-1.5 rounded-lg font-bold bg-slate-900 text-gray-400 border border-slate-800 transition-all cursor-pointer">
                        🖱️ โหมดเมาส์สัมผัส (จำลอง)
                    </button>
                </div>
            </div>

            <!-- กล่องจอวิดีโอและ Canvas เกมซ้อนทับกัน -->
            <div class="relative w-full aspect-video bg-slate-950 border-2 border-purple-900/50 rounded-2xl overflow-hidden game-border flex items-center justify-center">
                
                <!-- วิดีโอกล้องเว็บแคม (ซ่อนไว้ แต่อ่านข้อมูลเพื่อส่งให้ MediaPipe) -->
                <video id="webcam" autoplay playsinline muted class="absolute inset-0 w-full h-full object-cover opacity-30 pointer-events-none"></video>
                
                <!-- Canvas สำหรับวาดเอฟเฟกต์ AR, ดาว และเส้นเชื่อมพิกัดมือ -->
                <canvas id="gameCanvas" class="absolute inset-0 w-full h-full object-cover z-10 cursor-crosshair"></canvas>

                <!-- สถานะกำลังโหลดและเริ่มกล้องเว็บแคม -->
                <div id="loadingStatus" class="absolute inset-0 flex flex-col items-center justify-center bg-slate-950/90 z-20 transition-all duration-500">
                    <div class="w-12 h-12 border-4 border-purple-500 border-t-transparent rounded-full animate-spin mb-4"></div>
                    <p class="text-lg font-medium text-purple-300">กำลังเตรียมเซนเซอร์และโมเดล AR Hands...</p>
                    <p class="text-xs text-gray-500 mt-2">กรุณาอนุญาตให้ระบบเข้าถึงสิทธิ์กล้องถ่ายรูป</p>
                </div>
            </div>

            <!-- คำแนะนำการเล่นเกม -->
            <div class="bg-slate-900/40 border border-slate-800/80 p-5 rounded-2xl flex gap-3 text-sm text-gray-400">
                <span class="text-xl">💡</span>
                <div class="flex flex-col gap-1">
                    <span class="text-purple-300 font-bold">วิธีการคัดตัวด้วยระบบ AR:</span>
                    <p>1. ยกมือขึ้นมาอยู่ในมุมกล้องเว็บแคม ระบบจะติดตามพิกัดของมือ</p>
                    <p>2. เคลื่อนย้าย <strong class="text-pink-400">ปลายนิ้วชี้ของคุณ (วงกลมเรืองแสงสีชมพู)</strong> ไปแตะ <strong class="text-yellow-400">"ดาวสีทอง"</strong> ที่สุ่มเกิดขึ้นเพื่อสะสมคะแนน</p>
                    <p>3. คุณมีเวลา <strong class="text-white">30 วินาที</strong> ในการตอบสนองและสะสมคะแนนให้สูงที่สุด!</p>
                    <p class="text-xs text-gray-500 mt-1">*หากพบข้อขัดข้องในการใช้งานกล้อง หรือคอมพิวเตอร์ของคุณไม่มีเว็บแคม สามารถกดสลับด้านบนเพื่อใช้เมาส์เล่นจำลองได้*</p>
                </div>
            </div>
        </div>

        <!-- ส่วนขวา: ตารางบันทึกคะแนน สถิติการทดสอบ -->
        <div class="w-full lg:w-1/3 flex flex-col gap-6">
            
            <!-- กระดานโชว์คะแนนรอบปัจจุบัน และ คะแนนสูงสุดเดิม -->
            <div class="bg-slate-950 border border-pink-500/30 rounded-3xl p-6 neon-border relative overflow-hidden">
                <div class="absolute top-0 left-0 w-full h-1 bg-gradient-to-r from-pink-500 to-purple-500"></div>

                <div class="flex flex-col gap-6">
                    <div class="text-center">
                        <span class="text-xs text-pink-400 font-bold tracking-widest uppercase">ความเร็วการตอบสนอง</span>
                        <h2 class="text-5xl font-black tracking-tight text-white mt-1 mono-font" id="currentScore">0</h2>
                        <span class="text-xs text-gray-500 uppercase tracking-widest">คะแนนรอบปัจจุบัน (Points)</span>
                    </div>

                    <div class="grid grid-cols-2 gap-4 border-t border-purple-950 pt-4">
                        <div class="text-center border-r border-purple-950">
                            <span class="text-xs text-gray-400">เวลาทดสอบที่เหลือ</span>
                            <div class="text-2xl font-bold text-cyan-400 mono-font mt-1" id="timer">30.0s</div>
                        </div>
                        <div class="text-center">
                            <span class="text-xs text-gray-400">สถิติสูงสุดของคุณ</span>
                            <div class="text-2xl font-bold text-yellow-400 mono-font mt-1" id="dbHighScore"><?php echo $high_score; ?></div>
                        </div>
                    </div>

                    <!-- ปุ่มควบคุมหลัก -->
                    <div class="flex flex-col gap-3 mt-2">
                        <button id="btnStart" onclick="startGame()" 
                                class="w-full py-3 bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-500 hover:to-pink-500 text-white font-bold rounded-xl transition-all shadow-lg shadow-purple-950/40 cursor-pointer">
                            🚀 เริ่มการทดสอบ (30 วินาที)
                        </button>
                        
                        <button id="btnSaveScore" onclick="saveScoreToDatabase()" disabled
                                class="w-full py-3 bg-slate-900 border border-purple-900/60 text-purple-400 font-bold rounded-xl opacity-50 cursor-not-allowed transition-all">
                            💾 บันทึกสถิติลงโปรไฟล์สมัคร
                        </button>
                    </div>
                </div>
            </div>

            <!-- บัญชีนักกีฬาที่ล็อกอินอยู่ปัจจุบัน -->
            <div class="bg-slate-950 border border-slate-800 rounded-3xl p-6">
                <h3 class="font-bold text-white mb-4 flex items-center gap-2">
                    📋 โปรไฟล์นักกีฬาผู้สมัคร
                </h3>
                <div class="flex flex-col gap-3 text-sm">
                    <div class="flex justify-between border-b border-slate-900 pb-2">
                        <span class="text-gray-500">ชื่อ-นามสกุล</span>
                        <span class="text-gray-200 font-semibold"><?php echo htmlspecialchars($fullname); ?></span>
                    </div>
                    <div class="flex justify-between border-b border-slate-900 pb-2">
                        <span class="text-gray-500">อีเมลติดต่อ</span>
                        <span class="text-gray-200"><?php echo htmlspecialchars($_SESSION['email']); ?></span>
                    </div>
                    <div class="flex flex-col gap-1 border-b border-slate-900 pb-2">
                        <span class="text-gray-500">ประสบการณ์และบทบาทที่ระบุไว้</span>
                        <p class="text-xs text-gray-400 bg-slate-900 p-2.5 rounded-lg mt-1 whitespace-pre-line"><?php echo htmlspecialchars($user['game_exp'] ?? 'ไม่มีประวัติแข่งขัน'); ?></p>
                    </div>
                </div>
            </div>

        </div>
    </main>

    <!-- ส่วนท้ายเว็บ -->
    <footer class="border-t border-purple-900/20 bg-slate-950 py-6 px-6 text-center text-sm text-gray-500">
        <div class="max-w-7xl mx-auto text-center">
            © 2026 NEXUS ESPORTS Recruitment. Powered by MediaPipe Hand Tracking.
        </div>
    </footer>

    <!-- โค้ด JavaScript สำหรับเกม AR และการเชื่อมต่อ API -->
    <script>
        // กำหนดข้อมูลพื้นฐานจากเซสชัน PHP
        const playerId = <?php echo $_SESSION['user_id']; ?>;
        let dbHighScore = <?php echo $high_score; ?>;

        // อ้างอิงอิลิเมนต์ใน DOM
        const videoElement = document.getElementById('webcam');
        const canvasElement = document.getElementById('gameCanvas');
        const canvasCtx = canvasElement.getContext('2d');
        const loadingStatus = document.getElementById('loadingStatus');

        const scoreDisplay = document.getElementById('currentScore');
        const timerDisplay = document.getElementById('timer');
        const btnStart = document.getElementById('btnStart');
        const btnSaveScore = document.getElementById('btnSaveScore');
        const dbHighScoreDisplay = document.getElementById('dbHighScore');

        // สถานะของเกม
        let isPlaying = false;
        let playScore = 0;
        let timeLeft = 30.0;
        let gameTimer = null;
        let playMode = 'ar'; // โหมดการเล่น: 'ar' หรือ 'mouse'

        // ตำแหน่งพิกัดเป้าหมายดาว
        let starTarget = { x: 0.5, y: 0.5, size: 25 };
        // ตำแหน่งนิ้วชี้ของผู้เล่น (พิกัด normalized 0.0 - 1.0)
        let fingerPointer = { x: -1, y: -1, active: false };

        // โครงสร้างกล้องเว็บแคมและ MediaPipe
        let cameraInstance = null;
        let handsDetector = null;

        // ฟังก์ชันเริ่มสร้างวัตถุสุ่ม "ดาว" ตัวใหม่บนพิกัดความเหมาะสมของ canvas
        function spawnStar() {
            // สุ่มพิกัดแกน X และ Y ระหว่าง 0.1 ถึง 0.9 เพื่อกันดาวหลุดขอบจอจนเอื้อมไม่ถึง
            starTarget.x = 0.1 + Math.random() * 0.8;
            starTarget.y = 0.1 + Math.random() * 0.8;
        }

        // ฟังชันตั้งค่าโหมดการเล่น (AR หรือ เมาส์)
        function setPlayMode(mode) {
            if (isPlaying) {
                alert("กรุณาจบเกมรอบปัจจุบันก่อนเปลี่ยนโหมดการเล่นครับ!");
                return;
            }
            playMode = mode;
            
            const btnAr = document.getElementById('btn-mode-ar');
            const btnMouse = document.getElementById('btn-mode-mouse');

            if (mode === 'ar') {
                btnAr.className = "px-3 py-1.5 rounded-lg font-bold bg-purple-600 text-white border border-purple-500 shadow shadow-purple-500/30 transition-all cursor-pointer";
                btnMouse.className = "px-3 py-1.5 rounded-lg font-bold bg-slate-900 text-gray-400 border border-slate-800 transition-all cursor-pointer";
                initCameraAndAR(); // กลับมาเปิดกล้อง
            } else {
                btnAr.className = "px-3 py-1.5 rounded-lg font-bold bg-slate-900 text-gray-400 border border-slate-800 transition-all cursor-pointer";
                btnMouse.className = "px-3 py-1.5 rounded-lg font-bold bg-purple-600 text-white border border-purple-500 shadow shadow-purple-500/30 transition-all cursor-pointer";
                stopWebcam(); // ปิดการทำงานกล้อง
                loadingStatus.style.display = 'none'; // ซ่อนจอโหลดเนื่องจากโหมดเมาส์ไม่ต้องรอ AI
            }
        }

        // ฟังก์ชันสำหรับสุ่มเกิดพิกัดตอนเริ่มระบบแรกเริ่ม
        spawnStar();

        // ----------------- ส่วนของระบบเมาส์จำลองพิกัดกรณีไม่มีกล้อง -----------------
        canvasElement.addEventListener('mousemove', (e) => {
            if (playMode !== 'mouse') return;
            
            const rect = canvasElement.getBoundingClientRect();
            // พลิกพิกัด X เนื่องจากระบบ AR ออกแบบมาให้แสดงแบบ mirror สะท้อนกระจก
            const rawX = e.clientX - rect.left;
            const rawY = e.clientY - rect.top;
            
            fingerPointer.x = 1 - (rawX / rect.width);
            fingerPointer.y = rawY / rect.height;
            fingerPointer.active = true;
        });

        canvasElement.addEventListener('mouseleave', () => {
            if (playMode === 'mouse') {
                fingerPointer.active = false;
            }
        });

        // ----------------- ส่วนเชื่อมต่อกล้องและ MediaPipe Hands (AR Tracking) -----------------
        function initCameraAndAR() {
            loadingStatus.style.display = 'flex';
            
            if (handsDetector) {
                // หากมีการสร้างตัวตรวจจับไว้แล้ว ให้เปิดกล้องต่อได้ทันที
                startWebcamStream();
                return;
            }

            // ตั้งค่าเครื่องมือ MediaPipe Hands
            handsDetector = new Hands({
                locateFile: (file) => `https://cdn.jsdelivr.net/npm/@mediapipe/hands/${file}`
            });

            handsDetector.setOptions({
                maxNumHands: 1, // จับจุดพิกัดมือที่ใกล้กล้องที่สุดแค่มือเดียวเพื่อลดการประมวลผล
                modelComplexity: 1, // ความเสถียรและความแม่นยำสูง
                minDetectionConfidence: 0.5,
                minTrackingConfidence: 0.5
            });

            // คอลแบ็คเมื่อ MediaPipe ประมวลผลภาพกล้องและเจอพิกัดมือสำเร็จ
            handsDetector.onResults(onHandResults);

            startWebcamStream();
        }

        function startWebcamStream() {
            // เช็กการใช้งาน Navigator MediaDevices
            if (navigator.mediaDevices && navigator.mediaDevices.getUserMedia) {
                cameraInstance = new Camera(videoElement, {
                    onFrame: async () => {
                        if (playMode === 'ar') {
                            await handsDetector.send({ image: videoElement });
                        }
                    },
                    width: 640,
                    height: 480
                });

                cameraInstance.start()
                    .then(() => {
                        loadingStatus.style.display = 'none';
                        console.log("กล้องและโมเดล AR เริ่มทำงานสมบูรณ์");
                    })
                    .catch((err) => {
                        console.error("ไม่สามารถเริ่มกล้องได้: ", err);
                        alert("ไม่สามารถเปิดกล้องเว็บแคมได้! ระบบจะสลับไปยัง 'โหมดเมาส์สัมผัสจำลอง' ให้คุณทดสอบโดยไม่ต้องใช้กล้อง");
                        setPlayMode('mouse');
                    });
            } else {
                alert("เบราว์เซอร์นี้ไม่สนับสนุนการใช้เว็บแคม! ระบบจะปรับสลับไปสู่โหมดเมาส์แทน");
                setPlayMode('mouse');
            }
        }

        function stopWebcam() {
            if (cameraInstance) {
                const stream = videoElement.srcObject;
                if (stream) {
                    const tracks = stream.getTracks();
                    tracks.forEach(track => track.stop());
                }
                videoElement.srcObject = null;
            }
        }

        // ฟังก์ชันคอลแบ็คเมื่อตรวจจับมือเจอ
        function onHandResults(results) {
            // ล้างหน้าจอเพื่อเตรียมนอนดอวิดีโอและจุดพิกัดใหม่
            drawGameFrame();

            // ตรวจหาตำแหน่งว่าพบมือในเฟรมกล้องหรือไม่
            if (results.multiHandLandmarks && results.multiHandLandmarks.length > 0) {
                const handLandmarks = results.multiHandLandmarks[0];
                
                // ตรวจหาจุดปลายนิ้วชี้: Landmark หมายเลข 8 คือ INDEX_FINGER_TIP
                const indexFingerTip = handLandmarks[8];
                
                // บันทึกตำแหน่งและเปิดสถานะใช้งาน
                fingerPointer.x = indexFingerTip.x;
                fingerPointer.y = indexFingerTip.y;
                fingerPointer.active = true;

                // วาดเส้นข้อต่อของมือเป็นกราฟิกประกอบ (ถ้าต้องการเพิ่มความสวยงาม)
                drawHandSkeleton(handLandmarks);
            } else {
                // หากไม่เจอมือในเฟรม ให้ปิดการทำงาน pointer
                if (playMode === 'ar') {
                    fingerPointer.active = false;
                }
            }

            // ตรวจจับชนดาวในระหว่างวาดเฟรม
            checkCollision();
        }

        // ฟังก์ชันวาดเส้นข้อต่อมือเบื้องต้น
        function drawHandSkeleton(landmarks) {
            // วาดเฉพาะจุดข้อต่อสำคัญเพื่อเสริมดีไซน์ Futuristic HUD
            canvasCtx.fillStyle = 'rgba(236, 72, 153, 0.8)';
            canvasCtx.strokeStyle = 'rgba(139, 92, 246, 0.4)';
            canvasCtx.lineWidth = 2;

            // วาดวงกลมเล็กๆ ทับจุดข้อต่อสำคัญ
            const pointsToDraw = [0, 4, 8, 12, 16, 20];
            pointsToDraw.forEach(index => {
                const pt = landmarks[index];
                // แปลงพิกัดแบบ Mirror ซ้ายขวา เนื่องจากวิดีโอกล้องสะท้อนกระจก
                const cx = (1 - pt.x) * canvasElement.width;
                const cy = pt.y * canvasElement.height;
                
                canvasCtx.beginPath();
                canvasCtx.arc(cx, cy, 5, 0, 2 * Math.PI);
                canvasCtx.fill();
            });
        }

        // ----------------- ลูปกระดานเกมและการวาดกราฟิก Canvas -----------------
        function drawGameFrame() {
            const width = canvasElement.width = canvasElement.clientWidth;
            const height = canvasElement.height = canvasElement.clientHeight;

            canvasCtx.clearRect(0, 0, width, height);

            // หากเป็นโหมดกล้อง ให้ดึงภาพจากกล้องเว็บแคมมาวาดลงในพื้นหลังของ Canvas
            if (playMode === 'ar' && videoElement.srcObject) {
                // พลิกวาดกล้องด้านกระจก (Mirror Effect)
                canvasCtx.save();
                canvasCtx.translate(width, 0);
                canvasCtx.scale(-1, 1);
                canvasCtx.drawImage(videoElement, 0, 0, width, height);
                canvasCtx.restore();
            } else {
                // หากเป็นโหมดเมาส์ ให้วาดวอลเปเปอร์แนวอวกาศ/Esports สีมืด
                canvasCtx.fillStyle = '#0f172a';
                canvasCtx.fillRect(0, 0, width, height);
                
                // วาดเส้นกริดเรืองแสงแบบสไตล์เกมไซไฟ
                canvasCtx.strokeStyle = 'rgba(139, 92, 246, 0.08)';
                canvasCtx.lineWidth = 1;
                const gridSize = 40;
                for (let x = 0; x < width; x += gridSize) {
                    canvasCtx.beginPath();
                    canvasCtx.moveTo(x, 0);
                    canvasCtx.lineTo(x, height);
                    canvasCtx.stroke();
                }
                for (let y = 0; y < height; y += gridSize) {
                    canvasCtx.beginPath();
                    canvasCtx.moveTo(0, y);
                    canvasCtx.lineTo(width, y);
                    canvasCtx.stroke();
                }
            }

            // 1. วาดเป้าหมาย "ดาวสีทอง" (Gold Star Target) พร้อมแสงนีออนวาบวาบ
            if (isPlaying) {
                const starX = (1 - starTarget.x) * width; // กลับแกนเนื่องจาก mirror
                const starY = starTarget.y * height;
                
                // วาดรัศมีวงกลมเรืองแสงล้อมรอบดาว
                const pulse = 10 + Math.sin(Date.now() / 100) * 4;
                canvasCtx.beginPath();
                canvasCtx.arc(starX, starY, starTarget.size + pulse, 0, 2 * Math.PI);
                const starGlow = canvasCtx.createRadialGradient(starX, starY, 5, starX, starY, starTarget.size + pulse);
                starGlow.addColorStop(0, 'rgba(234, 179, 8, 0.5)');
                starGlow.addColorStop(1, 'rgba(234, 179, 8, 0)');
                canvasCtx.fillStyle = starGlow;
                canvasCtx.fill();

                // วาดตัวดาวรูปสมมาตร (5 แฉก) ด้วย Canvas Path
                drawStarShape(canvasCtx, starX, starY, 5, starTarget.size, starTarget.size / 2);
            }

            // 2. วาด Pointer ชี้ของปลายนิ้วผู้เล่น (Pink Ring Laser Pointer)
            if (fingerPointer.active) {
                const pointerX = (1 - fingerPointer.x) * width;
                const pointerY = fingerPointer.y * height;

                // วงแหวนขยายเรืองแสงสไตล์เป้าเล็ง Futuristic
                canvasCtx.beginPath();
                canvasCtx.arc(pointerX, pointerY, 20, 0, 2 * Math.PI);
                canvasCtx.strokeStyle = '#ec4899';
                canvasCtx.lineWidth = 3;
                canvasCtx.shadowColor = '#ec4899';
                canvasCtx.shadowBlur = 10;
                canvasCtx.stroke();
                canvasCtx.shadowBlur = 0; // เคลียร์เงาเพื่อไม่ให้ช้าในเฟรมถัดไป

                // จุดกึ่งกลางปลายนิ้ว
                canvasCtx.beginPath();
                canvasCtx.arc(pointerX, pointerY, 6, 0, 2 * Math.PI);
                canvasCtx.fillStyle = '#ffffff';
                canvasCtx.fill();
            }

            // วาดป้ายบอกสถานะการเชื่อมต่อกล้องหรือโมเดลจำลองบน Canvas
            canvasCtx.fillStyle = 'rgba(15, 23, 42, 0.7)';
            canvasCtx.fillRect(10, 10, 160, 32);
            canvasCtx.strokeStyle = 'rgba(139, 92, 246, 0.4)';
            canvasCtx.strokeRect(10, 10, 160, 32);
            canvasCtx.fillStyle = '#a78bfa';
            canvasCtx.font = '12px Kanit';
            canvasCtx.fillText(playMode === 'ar' ? '📷 SENSOR: ACTIVE' : '🖱️ CURSOR: STIMULATED', 20, 31);
        }

        // ฟังก์ชันวาดดาว 5 แฉกสีเหลืองทอง
        function drawStarShape(ctx, cx, cy, spikes, outerRadius, innerRadius) {
            let rot = Math.PI / 2 * 3;
            let x = cx;
            let y = cy;
            let step = Math.PI / spikes;

            ctx.beginPath();
            ctx.moveTo(cx, cy - outerRadius);
            for (let i = 0; i < spikes; i++) {
                x = cx + Math.cos(rot) * outerRadius;
                y = cy + Math.sin(rot) * outerRadius;
                ctx.lineTo(x, y);
                rot += step;

                x = cx + Math.cos(rot) * innerRadius;
                y = cy + Math.sin(rot) * innerRadius;
                ctx.lineTo(x, y);
                rot += step;
            }
            ctx.lineTo(cx, cy - outerRadius);
            ctx.closePath();
            ctx.fillStyle = '#facc15';
            ctx.fill();
            ctx.strokeStyle = '#eab308';
            ctx.lineWidth = 2;
            ctx.stroke();
        }

        // โหมดเมาส์ต้องการการอัปเดต Canvas ต่อเนื่องด้วย RequestAnimationFrame
        function animationLoop() {
            if (playMode === 'mouse') {
                drawGameFrame();
                checkCollision();
            }
            requestAnimationFrame(animationLoop);
        }
        requestAnimationFrame(animationLoop);

        // ----------------- ฟังก์ชันหลักของการทำงานเกม -----------------
        function startGame() {
            if (isPlaying) return;

            isPlaying = true;
            playScore = 0;
            timeLeft = 30.0;
            scoreDisplay.textContent = playScore;
            timerDisplay.textContent = timeLeft.toFixed(1) + 's';
            btnStart.disabled = true;
            btnStart.classList.add('opacity-50', 'cursor-not-allowed');
            btnSaveScore.disabled = true;
            btnSaveScore.classList.add('opacity-50', 'cursor-not-allowed');

            spawnStar();

            // เริ่มนับถอยหลังของเกมคัดเลือก
            gameTimer = setInterval(() => {
                timeLeft -= 0.1;
                if (timeLeft <= 0) {
                    timeLeft = 0;
                    endGame();
                }
                timerDisplay.textContent = timeLeft.toFixed(1) + 's';
            }, 100);
        }

        function checkCollision() {
            if (!isPlaying || !fingerPointer.active) return;

            const width = canvasElement.width;
            const height = canvasElement.height;

            // พิกัดจริงของดาวบน Canvas
            const starRealX = (1 - starTarget.x) * width;
            const starRealY = starTarget.y * height;

            // พิกัดจริงของปลายนิ้วผู้เล่นบน Canvas
            const pointerRealX = (1 - fingerPointer.x) * width;
            const pointerRealY = fingerPointer.y * height;

            // คำนวณระยะห่างระหว่างจุดสองจุดด้วยทฤษฎีพิธาโกรัส
            const distance = Math.sqrt(Math.pow(pointerRealX - starRealX, 2) + Math.pow(pointerRealY - starRealY, 2));

            // ตรวจเช็กหากชนกัน (ชนกันเมื่อระยะห่างน้อยกว่าขนาดดาว)
            if (distance < starTarget.size + 15) {
                // ได้แต้ม
                playScore++;
                scoreDisplay.textContent = playScore;
                
                // ให้ดาวสุ่มไปเกิดจุดใหม่ทันที
                spawnStar();
                
                // วาดเสียงหรือเอฟเฟกต์แฟลชพื้นหลังเล็กน้อยเพื่อเป็น feedback
                canvasCtx.fillStyle = 'rgba(234, 179, 8, 0.15)';
                canvasCtx.fillRect(0, 0, width, height);
            }
        }

        function endGame() {
            isPlaying = false;
            clearInterval(gameTimer);
            
            alert(`หมดเวลาทดสอบ! คะแนนที่คุณทำได้คือ ${playScore} แต้ม`);
            
            btnStart.disabled = false;
            btnStart.classList.remove('opacity-50', 'cursor-not-allowed');

            // หากคะแนนที่ได้สูงกว่าสถิติเดิม จะเปิดให้กดบันทึกข้อมูล
            if (playScore > dbHighScore) {
                btnSaveScore.disabled = false;
                btnSaveScore.classList.remove('opacity-50', 'cursor-not-allowed');
                btnSaveScore.classList.add('bg-gradient-to-r', 'from-pink-600', 'to-purple-600', 'text-white');
                btnSaveScore.textContent = '💾 กดเซฟสถิติใหม่ลงฐานข้อมูล';
            } else {
                btnSaveScore.textContent = 'บันทึกสถิติ (ต่ำกว่าสถิติเดิม)';
            }
        }

        // ----------------- คอลแบ็ค Fetch API ส่งคะแนนไปยัง PHP -----------------
        function saveScoreToDatabase() {
            if (playScore <= dbHighScore) {
                alert("คะแนนนี้ไม่สูงกว่าคะแนนสูงสุดเดิมของคุณ!");
                return;
            }

            // แสดงสถานะกำลังบันทึก
            btnSaveScore.textContent = 'กำลังอัปเดตสถิติ...';
            btnSaveScore.disabled = true;

            // เรียก Fetch API ส่งค่าไปที่ save_score.php โดยไม่ต้องรีโหลดหน้าเว็บ
            fetch('save_score.php', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({ score: playScore })
            })
            .then(response => response.json())
            .then(data => {
                if (data.status === 'success') {
                    dbHighScore = playScore;
                    dbHighScoreDisplay.textContent = dbHighScore;
                    
                    alert(`บันทึกสถิติสูงสุดใหม่สำเร็จ! คะแนนล่าสุดของคุณคือ: ${dbHighScore} แต้ม`);
                    
                    btnSaveScore.textContent = 'บันทึกสำเร็จเรียบร้อย ✓';
                    btnSaveScore.classList.remove('bg-gradient-to-r', 'from-pink-600', 'to-purple-600');
                    btnSaveScore.classList.add('bg-green-950/40', 'border-green-500', 'text-green-400');
                } else {
                    alert('เกิดข้อผิดพลาดในการบันทึก: ' + data.message);
                    btnSaveScore.textContent = 'เซฟคะแนนไม่สำเร็จ (ลองใหม่)';
                    btnSaveScore.disabled = false;
                }
            })
            .catch(error => {
                console.error('Error saving score:', error);
                alert('ไม่สามารถเชื่อมต่อเซิร์ฟเวอร์ PHP ได้ในขณะนี้');
                btnSaveScore.textContent = 'เซฟคะแนนไม่สำเร็จ (ลองใหม่)';
                btnSaveScore.disabled = false;
            });
        }

        // เริ่มต้นการทำงานของเซนเซอร์เว็บแคม
        window.onload = () => {
            initCameraAndAR();
        };
    </script>
</body>
</html>
