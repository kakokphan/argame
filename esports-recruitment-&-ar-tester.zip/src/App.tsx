/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect, useRef } from 'react';
import { 
  Camera, 
  MousePointer, 
  Trophy, 
  User, 
  Mail, 
  FileText, 
  Lock, 
  LogOut, 
  Play, 
  Sparkles, 
  CheckCircle2, 
  Database, 
  Download, 
  FileCode,
  ArrowRight,
  ShieldAlert,
  Gamepad2,
  Tv
} from 'lucide-react';

// ประกาศโมเดลประเภทข้อมูลผู้ใช้
interface UserProfile {
  id: number;
  username: string;
  fullname: string;
  email: string;
  game_exp: string;
  high_score: number;
}

export default function App() {
  // สถานะการเปลี่ยนหน้าจำลอง (Routing)
  const [currentScreen, setCurrentScreen] = useState<'index' | 'register' | 'game'>('index');
  
  // จำลองตารางฐานข้อมูลผู้ใช้ (MySQL Users) ใน LocalStorage
  const [users, setUsers] = useState<UserProfile[]>([]);
  const [currentUser, setCurrentUser] = useState<UserProfile | null>(null);

  // ฟอร์มสำหรับเข้าสู่ระบบ (Login)
  const [loginUsername, setLoginUsername] = useState('');
  const [loginPassword, setLoginPassword] = useState('');
  const [loginError, setLoginError] = useState('');

  // ฟอร์มสำหรับการสมัครสมาชิก (Register)
  const [regFullname, setRegFullname] = useState('');
  const [regEmail, setRegEmail] = useState('');
  const [regGameExp, setRegGameExp] = useState('');
  const [regUsername, setRegUsername] = useState('');
  const [regPassword, setRegPassword] = useState('');
  const [regError, setRegError] = useState('');
  const [regSuccess, setRegSuccess] = useState(false);

  // ข้อมูลเซสชันและเกม AR
  const [isPlaying, setIsPlaying] = useState(false);
  const [gameScore, setGameScore] = useState(0);
  const [timeLeft, setTimeLeft] = useState(30.0);
  const [playMode, setPlayMode] = useState<'ar' | 'mouse'>('ar');
  const [scriptsReady, setScriptsReady] = useState(false);
  const [loadingCamera, setLoadingCamera] = useState(false);

  // อ้างอิง Canvas & Video Element
  const videoRef = useRef<HTMLVideoElement | null>(null);
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const starTargetRef = useRef<{ x: number, y: number, size: number }>({ x: 0.5, y: 0.5, size: 25 });
  const fingerPointerRef = useRef<{ x: number, y: number, active: boolean }>({ x: -1, y: -1, active: false });

  // อ้างอิงตัวจัดการระยะเวลา (Timer & Anim)
  const timerIntervalRef = useRef<NodeJS.Timeout | null>(null);
  const animationFrameRef = useRef<number | null>(null);
  const cameraInstanceRef = useRef<any>(null);
  const handsDetectorRef = useRef<any>(null);

  // ส่วนของการแสดงคู่มือการใช้งานบน XAMPP
  const [showXamppGuide, setShowXamppGuide] = useState(false);

  // โหลดข้อมูลผู้ใช้เริ่มต้นและจำลอง MySQL Table ลงใน localStorage
  useEffect(() => {
    const savedUsers = localStorage.getItem('esports_db_users');
    if (savedUsers) {
      setUsers(JSON.parse(savedUsers));
    } else {
      // ข้อมูลผู้เล่นเริ่มต้นเลียนแบบตัวฐานข้อมูล SQL เพื่อให้กดเล่นทดสอบได้ทันที
      const defaultUsers: UserProfile[] = [
        {
          id: 1,
          username: 'proplayer1',
          fullname: 'อนาวิล สายฟ้า',
          email: 'proplayer1@esports.com',
          game_exp: 'ประสบการณ์แข่ง RoV Pro League Season 10 ตำแหน่ง Carry / Solo Lane',
          high_score: 15
        },
        {
          id: 2,
          username: 'ninja_fps',
          fullname: 'ศรุต พันธุ์ตา',
          email: 'ninja_fps@esports.com',
          game_exp: 'ประสบการณ์แข่ง Valorant Challengers Thailand ตำแหน่ง Duelist / Jett main',
          high_score: 22
        }
      ];
      localStorage.setItem('esports_db_users', JSON.stringify(defaultUsers));
      setUsers(defaultUsers);
    }

    // ตรวจสอบเช็กสถานะการเข้าสู่ระบบเดิม
    const loggedInUser = sessionStorage.getItem('current_recruitment_user');
    if (loggedInUser) {
      setCurrentUser(JSON.parse(loggedInUser));
      setCurrentScreen('game');
    }
  }, []);

  // โหลดไลบรารี MediaPipe Hands และ Camera Utils ผ่าน CDN
  useEffect(() => {
    let isMounted = true;
    const loadScript = (src: string): Promise<void> => {
      return new Promise((resolve, reject) => {
        const existing = document.querySelector(`script[src="${src}"]`);
        if (existing) {
          resolve();
          return;
        }
        const script = document.createElement('script');
        script.src = src;
        script.crossOrigin = 'anonymous';
        script.onload = () => resolve();
        script.onerror = () => reject();
        document.body.appendChild(script);
      });
    };

    Promise.all([
      loadScript('https://cdn.jsdelivr.net/npm/@mediapipe/camera_utils/camera_utils.js'),
      loadScript('https://cdn.jsdelivr.net/npm/@mediapipe/hands/hands.js')
    ]).then(() => {
      if (isMounted) {
        setScriptsReady(true);
        console.log("MediaPipe Hands loaded successfully inside React preview");
      }
    }).catch(err => {
      console.error("Failed to load MediaPipe from CDN in iframe, switching fallback mode", err);
    });

    return () => {
      isMounted = false;
    };
  }, []);

  // ฟังก์ชันสุ่มเป้าหมายดาว
  const spawnStar = () => {
    starTargetRef.current = {
      x: 0.15 + Math.random() * 0.7,
      y: 0.15 + Math.random() * 0.7,
      size: 25
    };
  };

  // ----------------- ส่วนของระบบเกมและการคำนวณเฟรม Canvas -----------------

  // ตรวจจับจุดชนของเป้าหมายและนิ้วชี้
  const checkCollision = (width: number, height: number) => {
    if (!isPlaying || !fingerPointerRef.current.active) return;

    // พิกัดจริงของดาว (สลับข้างกระจก)
    const starX = (1 - starTargetRef.current.x) * width;
    const starY = starTargetRef.current.y * height;

    // พิกัดจริงของเป้าชี้
    const pointerX = (1 - fingerPointerRef.current.x) * width;
    const pointerY = fingerPointerRef.current.y * height;

    // คำนวณระยะห่าง
    const distance = Math.sqrt(Math.pow(pointerX - starX, 2) + Math.pow(pointerY - starY, 2));

    // ชนกัน!
    if (distance < starTargetRef.current.size + 18) {
      setGameScore(prev => prev + 1);
      spawnStar();
    }
  };

  // วาดรูปดาว 5 แฉกสีเหลืองทอง
  const drawStarShape = (ctx: CanvasRenderingContext2D, cx: number, cy: number, outerRadius: number, innerRadius: number) => {
    let rot = Math.PI / 2 * 3;
    let x = cx;
    let y = cy;
    const step = Math.PI / 5;

    ctx.beginPath();
    ctx.moveTo(cx, cy - outerRadius);
    for (let i = 0; i < 5; i++) {
      x = cx + Math.cos(rot) * outerRadius;
      y = cy + Math.sin(rot) * outerRadius;
      ctx.lineTo(x, y);
      rot += step;

      x = cx + Math.cos(rot) * innerRadius;
      y = cy + Math.sin(rot) * innerRadius;
      ctx.lineTo(x, y);
      rot += step;
    }
    ctx.lineTo(cx, cy - outerRadius);
    ctx.closePath();
    ctx.fillStyle = '#facc15';
    ctx.fill();
    ctx.strokeStyle = '#eab308';
    ctx.lineWidth = 2.5;
    ctx.stroke();
  };

  // วาดเฟรมกระดานทั้งหมด
  const renderCanvasFrame = () => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const width = canvas.width = canvas.clientWidth;
    const height = canvas.height = canvas.clientHeight;

    ctx.clearRect(0, 0, width, height);

    // กรณีเป็นโหมดเมาส์สัมผัส หรือกล้องยังโหลดไม่ผ่าน
    if (playMode === 'mouse' || !videoRef.current || videoRef.current.readyState < 2) {
      // วาดพื้นหลังสไตล์ธีมเกม
      ctx.fillStyle = '#0f172a';
      ctx.fillRect(0, 0, width, height);

      // วาดเส้นตารางกริดล้ำๆ
      ctx.strokeStyle = 'rgba(139, 92, 246, 0.08)';
      ctx.lineWidth = 1;
      const gridSize = 40;
      for (let x = 0; x < width; x += gridSize) {
        ctx.beginPath();
        ctx.moveTo(x, 0);
        ctx.lineTo(x, height);
        ctx.stroke();
      }
      for (let y = 0; y < height; y += gridSize) {
        ctx.beginPath();
        ctx.moveTo(0, y);
        ctx.lineTo(width, y);
        ctx.stroke();
      }
    } else {
      // โหมดกล้อง AR: วาดเฟลตวิดีโอ (กลับกระจก)
      ctx.save();
      ctx.translate(width, 0);
      ctx.scale(-1, 1);
      ctx.drawImage(videoRef.current, 0, 0, width, height);
      ctx.restore();
    }

    // 1. วาดเป้าดาวสะสมคะแนน
    if (isPlaying) {
      const starX = (1 - starTargetRef.current.x) * width;
      const starY = starTargetRef.current.y * height;

      // รัศมีรั่วแสงนีออนรอบตัวดาว
      const pulse = 8 + Math.sin(Date.now() / 80) * 3;
      ctx.beginPath();
      ctx.arc(starX, starY, starTargetRef.current.size + pulse, 0, 2 * Math.PI);
      const glow = ctx.createRadialGradient(starX, starY, 4, starX, starY, starTargetRef.current.size + pulse);
      glow.addColorStop(0, 'rgba(234, 179, 8, 0.55)');
      glow.addColorStop(1, 'rgba(234, 179, 8, 0)');
      ctx.fillStyle = glow;
      ctx.fill();

      // วาดรูปร่างดาวจริง
      drawStarShape(ctx, starX, starY, starTargetRef.current.size, starTargetRef.current.size / 2);
    }

    // 2. วาด Pointer วงเล็งจับพิกัดนิ้วชี้
    if (fingerPointerRef.current.active) {
      const pX = (1 - fingerPointerRef.current.x) * width;
      const pY = fingerPointerRef.current.y * height;

      // วงกลมนอกเรืองแสงชมพู
      ctx.beginPath();
      ctx.arc(pX, pY, 20, 0, 2 * Math.PI);
      ctx.strokeStyle = '#ec4899';
      ctx.lineWidth = 3;
      ctx.shadowColor = '#ec4899';
      ctx.shadowBlur = 12;
      ctx.stroke();
      ctx.shadowBlur = 0;

      // จุดกลาง
      ctx.beginPath();
      ctx.arc(pX, pY, 6, 0, 2 * Math.PI);
      ctx.fillStyle = '#ffffff';
      ctx.fill();
    }

    // วาดกล่องข้อมูลสถานะเล็กๆ บนมุมซ้ายของ Canvas
    ctx.fillStyle = 'rgba(15, 23, 42, 0.85)';
    ctx.fillRect(12, 12, 170, 32);
    ctx.strokeStyle = 'rgba(168, 85, 247, 0.4)';
    ctx.strokeRect(12, 12, 170, 32);
    ctx.fillStyle = '#c084fc';
    ctx.font = 'bold 11px Inter, sans-serif';
    ctx.fillText(playMode === 'ar' ? '📷 SENSOR: ACTIVE' : '🖱️ CURSOR: TRACKING', 22, 32);
  };

  // แอนิเมชันลูปแบบไม่สะดุดสำหรับวาด Canvas ต่อเนื่อง
  useEffect(() => {
    const loop = () => {
      renderCanvasFrame();
      if (isPlaying) {
        checkCollision(canvasRef.current?.width || 640, canvasRef.current?.height || 480);
      }
      animationFrameRef.current = requestAnimationFrame(loop);
    };
    loop();

    return () => {
      if (animationFrameRef.current) {
        cancelAnimationFrame(animationFrameRef.current);
      }
    };
  }, [isPlaying, playMode]);

  // คอยเชื่อมต่อเซนเซอร์กล้องและ MediaPipe สำหรับโหมด AR
  useEffect(() => {
    if (!scriptsReady || playMode !== 'ar' || !isPlaying) {
      // เคลียร์กล้องเว็บแคมเมื่อหยุดเล่นหรือสลับโหมด
      if (cameraInstanceRef.current) {
        cameraInstanceRef.current.stop();
        cameraInstanceRef.current = null;
      }
      return;
    }

    const video = videoRef.current;
    if (!video) return;

    setLoadingCamera(true);

    const MP_Hands = (window as any).Hands;
    const MP_Camera = (window as any).Camera;

    if (!MP_Hands || !MP_Camera) {
      console.warn("MediaPipe library not fully initialized in window, falling back to Mouse Mode");
      setPlayMode('mouse');
      setLoadingCamera(false);
      return;
    }

    // เริ่มสร้าง Hands detector
    const hands = new MP_Hands({
      locateFile: (file: string) => `https://cdn.jsdelivr.net/npm/@mediapipe/hands/${file}`
    });

    hands.setOptions({
      maxNumHands: 1,
      modelComplexity: 1,
      minDetectionConfidence: 0.5,
      minTrackingConfidence: 0.5
    });

    // คอลแบ็คเมื่อเจอพิกัดมือ
    hands.onResults((results: any) => {
      if (results.multiHandLandmarks && results.multiHandLandmarks.length > 0) {
        const hand = results.multiHandLandmarks[0];
        // จุด 8 = INDEX_FINGER_TIP
        const tip = hand[8];
        fingerPointerRef.current = {
          x: tip.x,
          y: tip.y,
          active: true
        };
      } else {
        fingerPointerRef.current.active = false;
      }
    });

    handsDetectorRef.current = hands;

    // ติดตั้งสตรีมกล้อง
    const camera = new MP_Camera(video, {
      onFrame: async () => {
        if (handsDetectorRef.current && playMode === 'ar') {
          await handsDetectorRef.current.send({ image: video });
        }
      },
      width: 640,
      height: 480
    });

    cameraInstanceRef.current = camera;
    
    camera.start()
      .then(() => {
        setLoadingCamera(false);
        console.log("Webcam Tracking started successfully in React preview");
      })
      .catch((err: any) => {
        console.error("Camera capture failed inside container", err);
        setLoadingCamera(false);
        setPlayMode('mouse');
        alert("ระบบจำกัดการเข้าใช้กล้องเว็บแคมในหน้าตัวอย่างนี้! ระบบได้สลับไปให้คุณสัมผัสทดลองด้วย เมาส์จำลองพิกัด เพื่อให้ทดสอบความเสถียรของเกมและระบบเซฟสถิติได้ทันที");
      });

    return () => {
      if (cameraInstanceRef.current) {
        cameraInstanceRef.current.stop();
        cameraInstanceRef.current = null;
      }
      if (handsDetectorRef.current) {
        handsDetectorRef.current.close();
        handsDetectorRef.current = null;
      }
    };
  }, [scriptsReady, playMode, isPlaying]);

  // เหตุการณ์ของเมาส์สัมผัส (Mouse Mode)
  const handleMouseMove = (e: React.MouseEvent<HTMLCanvasElement>) => {
    if (playMode !== 'mouse') return;
    const canvas = canvasRef.current;
    if (!canvas) return;

    const rect = canvas.getBoundingClientRect();
    const rawX = e.clientX - rect.left;
    const rawY = e.clientY - rect.top;

    // แปลงพิกัดเป็น 0.0 - 1.0 (สลับแกน X เสมือนภาพกระจกสะท้อน)
    fingerPointerRef.current = {
      x: 1 - (rawX / rect.width),
      y: rawY / rect.height,
      active: true
    };
  };

  const handleMouseLeave = () => {
    if (playMode === 'mouse') {
      fingerPointerRef.current.active = false;
    }
  };

  // ----------------- คอนโทรลควบคุมเริ่ม/หยุดเกมคัดเลือก -----------------
  const startGame = () => {
    if (isPlaying) return;
    setIsPlaying(true);
    setGameScore(0);
    setTimeLeft(30.0);
    spawnStar();

    timerIntervalRef.current = setInterval(() => {
      setTimeLeft(prev => {
        if (prev <= 0.1) {
          clearInterval(timerIntervalRef.current!);
          setIsPlaying(false);
          return 0;
        }
        return Number((prev - 0.1).toFixed(1));
      });
    }, 100);
  };

  // บันทึกสถิติสูงสุดลงจำลองฐานข้อมูลใน LocalStorage
  const saveHighScoreSimulated = () => {
    if (!currentUser) return;
    if (gameScore <= currentUser.high_score) {
      alert("คะแนนครั้งนี้ยังไม่ชนะสถิติสูงสุดเดิมของคุณ!");
      return;
    }

    const updatedUsers = users.map(u => {
      if (u.id === currentUser.id) {
        return { ...u, high_score: gameScore };
      }
      return u;
    });

    const updatedProfile = { ...currentUser, high_score: gameScore };

    localStorage.setItem('esports_db_users', JSON.stringify(updatedUsers));
    sessionStorage.setItem('current_recruitment_user', JSON.stringify(updatedProfile));
    
    setUsers(updatedUsers);
    setCurrentUser(updatedProfile);

    alert(`🎉 ยินดีด้วย! บันทึกสถิติสูงสุดใหม่สำเร็จ: ${gameScore} แต้ม`);
  };

  // ----------------- ตรวจสอบฟังก์ชันของฟอร์ม (PHP Login & Register Sim) -----------------
  
  const handleLoginSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setLoginError('');

    if (!loginUsername || !loginPassword) {
      setLoginError('กรุณากรอกข้อมูลเพื่อเข้าสู่ระบบ');
      return;
    }

    // ตรวจหาข้อมูลจำลองใน Local DB
    const foundUser = users.find(u => u.username === loginUsername);
    if (foundUser) {
      // เข้าสู่ระบบสำเร็จ (รหัสผ่านในการจำลองอนุญาตให้ใช้รหัสใดก็ได้ หรือหากเป็นรหัสจำลอง '123456')
      sessionStorage.setItem('current_recruitment_user', JSON.stringify(foundUser));
      setCurrentUser(foundUser);
      setLoginUsername('');
      setLoginPassword('');
      setCurrentScreen('game');
    } else {
      setLoginError('ชื่อผู้ใช้งานหรือรหัสผ่านไม่ถูกต้อง! (ทดลองพิมพ์ proplayer1 หรือ ninja_fps)');
    }
  };

  const handleRegisterSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setRegError('');

    if (!regFullname || !regEmail || !regGameExp || !regUsername || !regPassword) {
      setRegError('กรุณากรอกข้อมูลให้ครบทุกช่อง!');
      return;
    }

    const isDuplicate = users.some(u => u.username === regUsername || u.email === regEmail);
    if (isDuplicate) {
      setRegError('Username หรือ Email นี้มีผู้สมัครใช้งานไปแล้ว!');
      return;
    }

    // สร้างข้อมูลผู้ใช้ใหม่ลง Local DB
    const newUser: UserProfile = {
      id: Date.now(),
      username: regUsername,
      fullname: regFullname,
      email: regEmail,
      game_exp: regGameExp,
      high_score: 0
    };

    const newUsersList = [...users, newUser];
    localStorage.setItem('esports_db_users', JSON.stringify(newUsersList));
    setUsers(newUsersList);

    // รีเซ็ตค่าฟอร์ม
    setRegFullname('');
    setRegEmail('');
    setRegGameExp('');
    setRegUsername('');
    setRegPassword('');
    
    // เปิดป๊อปอัปสมัครสำเร็จ
    setRegSuccess(true);
  };

  const handleLogout = () => {
    sessionStorage.removeItem('current_recruitment_user');
    setCurrentUser(null);
    setCurrentScreen('index');
  };

  return (
    <div className="bg-[#080c14] text-gray-100 min-h-screen flex flex-col justify-between overflow-x-hidden font-sans">
      
      {/* ส่วนหัวแอป (Header) */}
      <header className="border-b border-purple-900/40 bg-slate-950/75 backdrop-blur-md sticky top-0 z-40 px-6 py-4">
        <div className="max-w-7xl mx-auto flex justify-between items-center">
          <div className="flex items-center gap-3">
            <span className="text-xl md:text-2xl font-black bg-gradient-to-r from-purple-500 via-pink-500 to-cyan-400 bg-clip-text text-transparent tracking-wider">
              NEXUS ESPORTS
            </span>
            <span className="text-xs bg-purple-900/40 text-purple-300 border border-purple-500/30 px-2 py-0.5 rounded uppercase font-bold tracking-widest hidden sm:inline-block">
              AR Recruits
            </span>
          </div>

          <div className="flex items-center gap-3">
            {/* ปุ่มเปิดเอกสารสอนรันบน XAMPP */}
            <button 
              onClick={() => setShowXamppGuide(!showXamppGuide)}
              className="text-xs flex items-center gap-1.5 px-3 py-1.5 rounded-lg border border-cyan-500/30 text-cyan-400 hover:bg-cyan-950/20 hover:border-cyan-500 transition-all cursor-pointer"
            >
              <Database size={14} />
              <span>{showXamppGuide ? 'ปิดคู่มือ XAMPP' : 'คู่มือติดตั้งบน XAMPP'}</span>
            </button>

            {currentUser && (
              <div className="flex items-center gap-3">
                <div className="hidden md:flex flex-col items-end text-xs">
                  <span className="text-gray-400">สถานะนักกีฬา:</span>
                  <span className="text-pink-400 font-bold">{currentUser.fullname}</span>
                </div>
                <button 
                  onClick={handleLogout}
                  className="px-3 py-1.5 bg-red-950/30 hover:bg-red-900/40 text-red-400 border border-red-900/40 rounded-xl text-xs font-bold transition-all flex items-center gap-1 cursor-pointer"
                >
                  <LogOut size={13} />
                  <span>ออก</span>
                </button>
              </div>
            )}
          </div>
        </div>
      </header>

      {/* พื้นหลังรัศมีแสงนีออนเรืองแสงสำหรับ Live Preview */}
      <div className="absolute top-1/4 left-1/4 w-96 h-96 bg-purple-600/5 rounded-full blur-3xl -z-10 pointer-events-none"></div>
      <div className="absolute bottom-1/4 right-1/4 w-96 h-96 bg-pink-600/5 rounded-full blur-3xl -z-10 pointer-events-none"></div>

      {/* กล่องอธิบายสิทธิ์และการตรวจสอบกรณีเปิดใช้คู่มือรัน XAMPP */}
      {showXamppGuide && (
        <section className="bg-slate-950 border-b border-cyan-500/30 py-6 px-6 z-30 transition-all duration-300">
          <div className="max-w-4xl mx-auto flex flex-col gap-4">
            <h3 className="text-lg font-bold text-cyan-400 flex items-center gap-2">
              <FileCode size={20} />
              คู่มือการย้ายโค้ดไปรันบน XAMPP และ MySQL จริง
            </h3>
            <p className="text-xs text-gray-400 leading-relaxed">
              ในระบบตัวอย่างสดนี้ คุณกำลังทดสอบผ่าน <strong className="text-purple-300">React + Web Browser LocalStorage</strong> เพื่อให้ทดลองระบบ AR จับพิกัดกล้องเว็บแคมและการสะสมคะแนนได้ทันทีใน iFrame 
              แต่สำหรับระบบใช้งานจริง คณะกรรมการผู้พัฒนาเตรียมไฟล์ภาษา PHP และฐานข้อมูล SQL ครบถ้วนเสร็จสมบูรณ์ที่สามารถนำไปเปิดบน XAMPP ได้ดังนี้:
            </p>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-xs mt-2">
              <div className="bg-slate-900/60 p-3.5 border border-purple-900/40 rounded-xl">
                <span className="text-purple-300 font-bold block mb-1">1. ติดตั้งฐานข้อมูล (MySQL)</span>
                เปิด phpMyAdmin เพื่อกดสร้างฐานข้อมูลใหม่ชื่อ <code className="text-pink-400 font-mono">esports_db</code> จากนั้นกดยอดข้อมูลด้วยคำสั่งในไฟล์ <code className="text-yellow-400 font-mono">database.sql</code>
              </div>
              <div className="bg-slate-900/60 p-3.5 border border-purple-900/40 rounded-xl">
                <span className="text-purple-300 font-bold block mb-1">2. คัดลอกไฟล์ลง htdocs</span>
                คัดลอกไฟล์ PHP ทั้งหมดในโครงการนี้ (<code className="text-pink-400 font-mono">index.php</code>, <code className="text-pink-400 font-mono">register.php</code>, <code className="text-pink-400 font-mono">game.php</code>, <code className="text-pink-400 font-mono">db_connect.php</code>, <code className="text-pink-400 font-mono">save_score.php</code>) ไปวางในโฟลเดอร์ <code className="text-yellow-400 font-mono">C:/xampp/htdocs/esports/</code>
              </div>
              <div className="bg-slate-900/60 p-3.5 border border-purple-900/40 rounded-xl">
                <span className="text-purple-300 font-bold block mb-1">3. เปิดเว็บเบราว์เซอร์</span>
                สตาร์ทเซนเซอร์ Apache และ MySQL ในโปรแกรม XAMPP Control Panel และเข้าหน้าสมัครสมาชิกผ่านลิงก์ <a href="http://localhost/esports/" target="_blank" rel="noopener noreferrer" className="text-cyan-400 underline">http://localhost/esports/</a>
              </div>
            </div>
            <div className="text-center mt-2 border-t border-slate-900 pt-3">
              <button 
                onClick={() => setShowXamppGuide(false)}
                className="px-4 py-1.5 bg-cyan-950 text-cyan-300 font-semibold border border-cyan-800 rounded-lg hover:bg-cyan-900 transition-all text-xs cursor-pointer"
              >
                เข้าใจแล้ว และปิดหน้าต่างสอนนี้
              </button>
            </div>
          </div>
        </section>
      )}

      {/* หน้าที่ 1: หน้าแรกและฟอร์มเข้าสู่ระบบ (Index Page & Login Form) */}
      {currentScreen === 'index' && (
        <main className="max-w-7xl mx-auto px-6 py-8 md:py-16 flex-grow flex flex-col lg:flex-row items-center justify-center gap-12 w-full">
          
          {/* ซ้าย: รายละเอียดเนื้อหาโครงการคัดเลือก */}
          <div className="lg:w-1/2 flex flex-col gap-6 text-center lg:text-left">
            <div className="inline-flex items-center justify-center lg:justify-start gap-2 text-pink-400 font-semibold tracking-wider text-xs uppercase">
              <span className="w-2.5 h-2.5 rounded-full bg-pink-500 animate-pulse"></span>
              โครงการคัดเลือกนักกีฬาดาวรุ่งระดับประเทศ
            </div>
            <h1 className="text-4xl md:text-5xl lg:text-6xl font-black tracking-tight leading-tight text-white">
              ปลุกศักยภาพ <br />
              <span className="bg-gradient-to-r from-purple-400 via-pink-500 to-cyan-400 bg-clip-text text-transparent filter drop-shadow-[0_0_15px_rgba(236,72,153,0.3)]">
                แชมป์เปี้ยนอีสปอร์ต
              </span>
            </h1>
            <p className="text-gray-400 text-sm md:text-base leading-relaxed max-w-xl">
              ยินดีต้อนรับสู่ <strong className="text-purple-300">NEXUS ESPORTS Recruitment 2026</strong> โครงการทดสอบและคัดกรองขีดความสามารถนักกีฬาหน้าใหม่เพื่อผลักดันสู่ลีกระดับมืออาชีพร่วมกับสังกัดระดับแถวหน้า
            </p>
            
            <div className="bg-slate-900/60 border border-purple-900/40 p-5 rounded-2xl backdrop-blur-md flex flex-col gap-3 text-left">
              <h3 className="text-purple-300 font-bold text-sm md:text-base flex items-center gap-2">
                <Sparkles size={18} className="text-pink-400" />
                ระบบทดสอบสมรรถภาพและการตอบสนอง AR บนหน้าเว็บ
              </h3>
              <p className="text-xs md:text-sm text-gray-400 leading-relaxed">
                ไม่ใช่แค่ดูประวัติการเล่น! คณะกรรมการต้องการเห็นพิกัดความเร็วการตอบสนองของคุณผ่านกล้อง โดยตรวจจับพิกัดปลายนิ้วชี้ของคุณลอยทับเป้าหมาย (Augmented Reality) แบบเรียลไทม์ เพื่อคำนวณความเร็วระดับเสี้ยววินาทีที่ดีที่สุด!
              </p>
            </div>

            <div className="text-xs text-gray-500 border border-slate-900 p-3 rounded-xl inline-flex flex-wrap items-center justify-center lg:justify-start gap-2">
              <span className="bg-slate-900 px-2 py-0.5 rounded text-gray-400 border border-slate-800">บัญชีทดสอบในระบบจำลอง:</span>
              <span className="font-mono text-pink-300 bg-slate-950 px-1.5 py-0.5 rounded">proplayer1</span>
              <span>หรือ</span>
              <span className="font-mono text-pink-300 bg-slate-950 px-1.5 py-0.5 rounded">ninja_fps</span>
              <span className="text-gray-400">(รหัสผ่านกรอกอะไรก็ได้)</span>
            </div>
          </div>

          {/* ขวา: ฟอร์มล็อกอินเข้าใช้งาน */}
          <div className="w-full max-w-md lg:w-1/2">
            <div className="bg-slate-950/80 border border-purple-500/25 rounded-3xl p-6 md:p-8 shadow-[0_0_30px_rgba(168,85,247,0.15)] backdrop-blur-lg relative overflow-hidden">
              <div className="absolute top-0 left-0 w-full h-1 bg-gradient-to-r from-purple-500 via-pink-500 to-cyan-400"></div>

              <h2 class="text-xl md:text-2xl font-bold text-center mb-6 text-white tracking-wide">
                เข้าสู่ระบบคัดเลือกตัว
              </h2>

              {loginError && (
                <div className="bg-red-950/40 border border-red-500/40 text-red-300 text-xs p-3.5 rounded-xl mb-5 flex items-start gap-2 leading-relaxed">
                  <ShieldAlert size={16} className="text-red-400 shrink-0 mt-0.5" />
                  <span>{loginError}</span>
                </div>
              )}

              <form onSubmit={handleLoginSubmit} class="flex flex-col gap-4">
                <div class="flex flex-col gap-1.5">
                  <label htmlFor="login-user" class="text-xs text-gray-400 font-medium">Username (ชื่อผู้ใช้งาน)</label>
                  <div className="relative">
                    <span className="absolute left-3 top-3.5 text-gray-600"><User size={16} /></span>
                    <input 
                      type="text" 
                      id="login-user"
                      value={loginUsername}
                      onChange={(e) => setLoginUsername(e.target.value)}
                      placeholder="กรอกชื่อผู้ใช้งาน" 
                      required
                      className="w-full pl-10 pr-4 py-3 rounded-xl bg-slate-900 border border-purple-900/50 focus:border-purple-500 focus:ring-1 focus:ring-purple-500/30 outline-none text-white text-sm transition-all"
                    />
                  </div>
                </div>

                <div class="flex flex-col gap-1.5">
                  <label htmlFor="login-pass" class="text-xs text-gray-400 font-medium">Password (รหัสผ่าน)</label>
                  <div className="relative">
                    <span className="absolute left-3 top-3.5 text-gray-600"><Lock size={16} /></span>
                    <input 
                      type="password" 
                      id="login-pass"
                      value={loginPassword}
                      onChange={(e) => setLoginPassword(e.target.value)}
                      placeholder="กรอกรหัสผ่าน" 
                      required
                      className="w-full pl-10 pr-4 py-3 rounded-xl bg-slate-900 border border-purple-900/50 focus:border-purple-500 focus:ring-1 focus:ring-purple-500/30 outline-none text-white text-sm transition-all"
                    />
                  </div>
                </div>

                <button 
                  type="submit"
                  className="w-full mt-3 py-3 bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-500 hover:to-pink-500 text-white font-bold rounded-xl shadow-lg shadow-purple-950/40 hover:shadow-purple-500/10 active:scale-[0.98] transition-all cursor-pointer text-sm"
                >
                  ล็อกอินเข้าสู่ระบบคัดเลือก
                </button>
              </form>

              <div className="relative flex py-4 items-center">
                <div className="flex-grow border-t border-purple-950/40"></div>
                <span className="flex-shrink mx-3 text-[10px] text-gray-500 uppercase tracking-widest">ยังไม่เคยสมัครตัวนักกีฬา?</span>
                <div className="flex-grow border-t border-purple-950/40"></div>
              </div>

              <button 
                onClick={() => {
                  setRegError('');
                  setCurrentScreen('register');
                }}
                className="w-full py-3 border border-pink-500/30 hover:border-pink-500 text-pink-400 hover:text-pink-300 font-semibold rounded-xl bg-pink-950/10 hover:bg-pink-950/20 transition-all text-sm flex items-center justify-center gap-1.5 cursor-pointer"
              >
                <span>🎯 ลงทะเบียนนักกีฬาใหม่</span>
                <ArrowRight size={14} />
              </button>
            </div>
          </div>

        </main>
      )}

      {/* หน้าที่ 2: ฟอร์มสมัครสมาชิก (Register Page) */}
      {currentScreen === 'register' && (
        <main className="max-w-xl mx-auto px-6 py-8 flex-grow flex items-center justify-center w-full">
          <div className="w-full bg-slate-950/80 border border-pink-500/25 rounded-3xl p-6 md:p-8 shadow-[0_0_30px_rgba(236,72,153,0.1)] backdrop-blur-lg relative overflow-hidden">
            <div className="absolute top-0 left-0 w-full h-1 bg-gradient-to-r from-pink-500 to-purple-500"></div>

            <h2 className="text-2xl font-extrabold text-center mb-1 text-white tracking-wide">
              ลงทะเบียนนักกีฬา
            </h2>
            <p className="text-center text-gray-400 text-xs mb-6">
              ระบุประวัติเพื่อเข้ารับการพิจารณาเป็นตัวจริงร่วมกับลีกชั้นนำ
            </p>

            {regError && (
              <div className="bg-red-950/40 border border-red-500/40 text-red-300 text-xs p-3 rounded-xl mb-5 flex items-start gap-2">
                <ShieldAlert size={16} className="text-red-400 shrink-0 mt-0.5" />
                <span>{regError}</span>
              </div>
            )}

            <form onSubmit={handleRegisterSubmit} className="flex flex-col gap-4">
              
              {/* ชื่อ-นามสกุล */}
              <div className="flex flex-col gap-1">
                <label htmlFor="reg-fullname" className="text-xs text-gray-400 font-medium">ชื่อ - นามสกุลจริง</label>
                <div className="relative">
                  <span className="absolute left-3 top-3.5 text-gray-600"><User size={15} /></span>
                  <input 
                    type="text" 
                    id="reg-fullname"
                    value={regFullname}
                    onChange={(e) => setRegFullname(e.target.value)}
                    placeholder="เช่น นายกิตติภพ นักรบ" 
                    required
                    className="w-full pl-10 pr-4 py-3 rounded-xl bg-slate-900 border border-purple-900/40 focus:border-pink-500 focus:ring-1 focus:ring-pink-500/20 outline-none text-white text-sm transition-all"
                  />
                </div>
              </div>

              {/* อีเมล */}
              <div className="flex flex-col gap-1">
                <label htmlFor="reg-email" className="text-xs text-gray-400 font-medium">อีเมลติดต่อ (Email)</label>
                <div className="relative">
                  <span className="absolute left-3 top-3.5 text-gray-600"><Mail size={15} /></span>
                  <input 
                    type="email" 
                    id="reg-email"
                    value={regEmail}
                    onChange={(e) => setRegEmail(e.target.value)}
                    placeholder="เช่น kittipop@esports.com" 
                    required
                    className="w-full pl-10 pr-4 py-3 rounded-xl bg-slate-900 border border-purple-900/40 focus:border-pink-500 focus:ring-1 focus:ring-pink-500/20 outline-none text-white text-sm transition-all"
                  />
                </div>
              </div>

              {/* ประสบการณ์ */}
              <div className="flex flex-col gap-1">
                <label htmlFor="reg-exp" className="text-xs text-gray-400 font-medium">ประสบการณ์การเล่น / ตำแหน่งที่ถนัด / ลีกที่เข้าร่วม</label>
                <div className="relative">
                  <span className="absolute left-3 top-3 text-gray-600"><FileText size={15} /></span>
                  <textarea 
                    id="reg-exp"
                    value={regGameExp}
                    onChange={(e) => setRegGameExp(e.target.value)}
                    placeholder="เช่น เล่นตำแหน่ง Duelist (Valorant) ประสบการณ์เคยแข่งรายการระดับประเทศ ได้อันดับ Top 8" 
                    required
                    rows={2}
                    className="w-full pl-10 pr-4 py-2.5 rounded-xl bg-slate-900 border border-purple-900/40 focus:border-pink-500 focus:ring-1 focus:ring-pink-500/20 outline-none text-white text-xs transition-all resize-none"
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4 border-t border-purple-950/40 pt-4 mt-1">
                {/* ชื่อผู้ใช้งาน */}
                <div className="flex flex-col gap-1">
                  <label htmlFor="reg-user" className="text-xs text-gray-400 font-medium">ตั้ง Username</label>
                  <input 
                    type="text" 
                    id="reg-user"
                    value={regUsername}
                    onChange={(e) => setRegUsername(e.target.value)}
                    placeholder="ขั้นต่ำ 4 ตัวอักษร" 
                    required
                    className="w-full px-4 py-2.5 rounded-xl bg-slate-900 border border-purple-900/40 focus:border-pink-500 focus:ring-1 focus:ring-pink-500/20 outline-none text-white text-sm transition-all"
                  />
                </div>

                {/* รหัสผ่าน */}
                <div className="flex flex-col gap-1">
                  <label htmlFor="reg-pass" className="text-xs text-gray-400 font-medium">ตั้ง Password</label>
                  <input 
                    type="password" 
                    id="reg-pass"
                    value={regPassword}
                    onChange={(e) => setRegPassword(e.target.value)}
                    placeholder="ขั้นต่ำ 6 ตัวอักษร" 
                    required
                    className="w-full px-4 py-2.5 rounded-xl bg-slate-900 border border-purple-900/40 focus:border-pink-500 focus:ring-1 focus:ring-pink-500/20 outline-none text-white text-sm transition-all"
                  />
                </div>
              </div>

              <button 
                type="submit"
                className="w-full mt-3 py-3 bg-gradient-to-r from-pink-600 to-purple-600 hover:from-pink-500 hover:to-purple-500 text-white font-bold rounded-xl shadow-lg shadow-pink-950/30 active:scale-[0.98] transition-all cursor-pointer text-sm"
              >
                ยืนยันและส่งใบสมัครนักกีฬา
              </button>
            </form>

            <div className="text-center mt-5">
              <span className="text-xs text-gray-500">มีบัญชีแล้ว?</span>
              <button 
                onClick={() => setCurrentScreen('index')}
                className="text-pink-400 font-semibold text-xs ml-1.5 hover:underline cursor-pointer"
              >
                ย้อนกลับไปหน้าล็อกอิน
              </button>
            </div>
          </div>

          {/* ป๊อปอัปสมัครสำเร็จ */}
          {regSuccess && (
            <div className="fixed inset-0 bg-black/80 backdrop-blur-sm flex items-center justify-center p-6 z-50 animate-fade-in">
              <div className="w-full max-w-md bg-slate-900 border border-green-500/40 p-6 md:p-8 rounded-3xl text-center shadow-2xl">
                <div className="w-14 h-14 bg-green-950/80 border border-green-500 text-green-400 rounded-full flex items-center justify-center text-2xl mx-auto mb-4">
                  <CheckCircle2 size={28} />
                </div>
                <h3 className="text-xl md:text-2xl font-bold text-white mb-2">ลงทะเบียนสำเร็จ!</h3>
                <p className="text-gray-400 text-xs md:text-sm mb-6 leading-relaxed">
                  ยินดีต้อนรับสู่ NEXUS ESPORTS! บัญชีทดลองของคุณได้รับการบันทึกแล้ว กรุณาใช้ชื่อผู้ใช้และรหัสผ่านที่คุณได้ตั้งไว้มาล็อกอินเข้าเล่นเกม AR คัดฝีมือ
                </p>
                <button 
                  onClick={() => {
                    setRegSuccess(false);
                    setCurrentScreen('index');
                  }}
                  className="w-full py-2.5 bg-gradient-to-r from-green-500 to-emerald-600 hover:from-green-400 hover:to-emerald-500 text-slate-950 font-bold rounded-xl shadow-lg transition-all cursor-pointer text-sm"
                >
                  ย้อนกลับสู่หน้าล็อกอิน
                </button>
              </div>
            </div>
          )}
        </main>
      )}

      {/* หน้าที่ 3: หน้าเกมทดสอบสมรรถภาพ AR Hand Tracking (Game Stage) */}
      {currentScreen === 'game' && currentUser && (
        <main className="max-w-7xl mx-auto px-6 py-6 flex-grow w-full flex flex-col lg:flex-row gap-8 items-start justify-center">
          
          {/* ซ้าย: ส่วนจับพิกัดวิดีโอกล้องเว็บแคม และ Canvas */}
          <div className="w-full lg:w-2/3 flex flex-col gap-4">
            
            {/* แผงควบคุมและเลือกโหมดเซนเซอร์ */}
            <div className="bg-slate-950 border border-purple-900/40 rounded-2xl p-4 flex flex-wrap justify-between items-center gap-4">
              <div className="flex items-center gap-3">
                <span className="relative flex h-3 w-3 shrink-0">
                  <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-green-400 opacity-75"></span>
                  <span className="relative inline-flex rounded-full h-3 w-3 bg-green-500"></span>
                </span>
                <span className="text-xs md:text-sm font-semibold text-gray-300">กล้องตรวจจับการเคลื่อนไหวเสมือนจริง</span>
              </div>

              {/* ปุ่มสลับโหมดเซ็นเซอร์สำหรับ Iframe ในเบราว์เซอร์ */}
              <div className="flex gap-2 text-xs">
                <button 
                  onClick={() => setPlayMode('ar')}
                  className={`px-3 py-1.5 rounded-lg font-bold transition-all flex items-center gap-1.5 cursor-pointer ${
                    playMode === 'ar' 
                      ? 'bg-purple-600 text-white border border-purple-500 shadow shadow-purple-500/20' 
                      : 'bg-slate-900 text-gray-400 border border-slate-800'
                  }`}
                >
                  <Camera size={13} />
                  <span>โหมดกล้องเว็บแคม (AR)</span>
                </button>
                <button 
                  onClick={() => setPlayMode('mouse')}
                  className={`px-3 py-1.5 rounded-lg font-bold transition-all flex items-center gap-1.5 cursor-pointer ${
                    playMode === 'mouse' 
                      ? 'bg-purple-600 text-white border border-purple-500 shadow shadow-purple-500/20' 
                      : 'bg-slate-900 text-gray-400 border border-slate-800'
                  }`}
                >
                  <MousePointer size={13} />
                  <span>โหมดเมาส์จำลอง</span>
                </button>
              </div>
            </div>

            {/* ส่วนกล้องและจอภาพเกม */}
            <div className="relative w-full aspect-video bg-slate-950 border-2 border-purple-900/40 rounded-2xl overflow-hidden shadow-2xl flex items-center justify-center">
              
              {/* วิดีโอกล้องเว็บแคม (แฝงไว้หลัง Canvas) */}
              <video 
                ref={videoRef}
                autoPlay 
                playsInline 
                muted 
                className="absolute inset-0 w-full h-full object-cover opacity-25 pointer-events-none transform -scale-x-100"
              />

              {/* กระดาน Canvas วาดเป้าดาว และเป้าพิกัด */}
              <canvas 
                ref={canvasRef}
                onMouseMove={handleMouseMove}
                onMouseLeave={handleMouseLeave}
                className="absolute inset-0 w-full h-full object-cover z-10 cursor-crosshair"
              />

              {/* แถบการโหลดเว็บแคม */}
              {loadingCamera && playMode === 'ar' && (
                <div className="absolute inset-0 flex flex-col items-center justify-center bg-slate-950/95 z-20 transition-all duration-300">
                  <div className="w-10 h-10 border-4 border-purple-500 border-t-transparent rounded-full animate-spin mb-4"></div>
                  <p className="text-sm font-medium text-purple-300">กำลังติดต่อกล้องเว็บแคมและประมวลผลโมเดล AI...</p>
                  <p className="text-[10px] text-gray-500 mt-1">กรุณากดตอบตกลง 'อนุญาตสิทธิ์กล้อง' ในแผงสิทธิ์ของบราวเซอร์ของคุณ</p>
                </div>
              )}
            </div>

            {/* บล็อกช่วยเหลือ */}
            <div className="bg-slate-900/40 border border-slate-800/80 p-4 rounded-xl flex gap-3 text-xs text-gray-400">
              <span className="text-lg">💡</span>
              <div className="flex flex-col gap-1 leading-relaxed">
                <span className="text-purple-300 font-bold">เทคนิคการร่วมคัดเลือกนักกีฬา:</span>
                <p>เคลื่อนไหว <strong className="text-pink-400">ปลายนิ้วชี้ของคุณ (หรือเป้าเมาส์ในโหมดจำลอง)</strong> ไปชนกับ <strong className="text-yellow-400">"ดาวสีเหลือง"</strong> ที่จะสุ่มเกิดบนจุดต่างๆ บน Canvas ให้รวดเร็วที่สุด คุณมีเวลาทั้งหมด 30 วินาที ในการพิสูจน์ขีดความแม่นยำและการตอบสนองสายตาเพื่อส่งผลคะแนนสะสม!</p>
              </div>
            </div>
          </div>

          {/* ขวา: สถิติกระดานคะแนน */}
          <div className="w-full lg:w-1/3 flex flex-col gap-6">
            
            {/* กระดานความเร็ว */}
            <div className="bg-slate-950 border border-pink-500/25 rounded-3xl p-6 shadow-xl relative overflow-hidden">
              <div className="absolute top-0 left-0 w-full h-1 bg-gradient-to-r from-pink-500 to-purple-500"></div>

              <div className="flex flex-col gap-5">
                <div className="text-center">
                  <span className="text-[10px] text-pink-400 font-bold tracking-widest uppercase">สมรรถภาพการตอบสนอง</span>
                  <h2 className="text-5xl font-black text-white mt-1 font-mono tracking-tight">{gameScore}</h2>
                  <span className="text-[10px] text-gray-500 uppercase tracking-widest block mt-0.5">คะแนนสะสมรอบปัจจุบัน</span>
                </div>

                <div className="grid grid-cols-2 gap-4 border-t border-purple-950/40 pt-4">
                  <div className="text-center border-r border-purple-950/40">
                    <span className="text-xs text-gray-400">เวลาทดสอบเหลือ</span>
                    <div className="text-xl font-bold text-cyan-400 font-mono mt-1">{timeLeft.toFixed(1)}s</div>
                  </div>
                  <div className="text-center">
                    <span className="text-xs text-gray-400">สถิติสูงสุดคุณ</span>
                    <div className="text-xl font-bold text-yellow-400 font-mono mt-1">{currentUser.high_score}</div>
                  </div>
                </div>

                <div className="flex flex-col gap-2.5 mt-2">
                  <button 
                    onClick={startGame}
                    disabled={isPlaying}
                    className={`w-full py-3 bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-500 hover:to-pink-500 text-white font-bold rounded-xl shadow-lg transition-all cursor-pointer text-sm ${
                      isPlaying ? 'opacity-50 cursor-not-allowed' : ''
                    }`}
                  >
                    <span className="flex items-center justify-center gap-1.5">
                      <Play size={15} />
                      <span>{isPlaying ? 'ระบบกำลังบันทึกพิกัด...' : '🚀 เริ่มทดสอบ (30 วินาที)'}</span>
                    </span>
                  </button>

                  <button 
                    onClick={saveHighScoreSimulated}
                    disabled={isPlaying || gameScore <= currentUser.high_score}
                    className={`w-full py-3 border font-bold rounded-xl transition-all text-sm flex items-center justify-center gap-1.5 ${
                      !isPlaying && gameScore > currentUser.high_score
                        ? 'bg-gradient-to-r from-pink-600 to-purple-600 text-white border-pink-500 cursor-pointer shadow-lg shadow-pink-950/30'
                        : 'bg-slate-900 border-purple-900/40 text-purple-400/50 opacity-40 cursor-not-allowed'
                    }`}
                  >
                    <Download size={14} />
                    <span>บันทึกสถิติใหม่ลงฐานข้อมูล</span>
                  </button>
                </div>
              </div>
            </div>

            {/* โปรไฟล์ย่อของผู้ร่วมทดสอบ */}
            <div className="bg-slate-950 border border-slate-900 rounded-3xl p-6">
              <h3 className="font-bold text-white text-sm mb-3 flex items-center gap-2">
                <Gamepad2 size={16} className="text-purple-400" />
                ใบสมัครที่จัดเก็บลง MySQL
              </h3>
              <div className="flex flex-col gap-3 text-xs leading-relaxed">
                <div className="flex justify-between border-b border-slate-900 pb-2">
                  <span className="text-gray-500">ชื่อนักกีฬา</span>
                  <span className="text-gray-200 font-semibold">{currentUser.fullname}</span>
                </div>
                <div className="flex justify-between border-b border-slate-900 pb-2">
                  <span className="text-gray-500">อีเมลติดต่อ</span>
                  <span className="text-gray-200">{currentUser.email}</span>
                </div>
                <div className="flex flex-col gap-1">
                  <span className="text-gray-500">รายละเอียดตำแหน่งและทักษะเกม</span>
                  <p className="text-gray-400 bg-slate-900 p-2.5 rounded-lg mt-1 whitespace-pre-line text-[11px] leading-relaxed">
                    {currentUser.game_exp}
                  </p>
                </div>
              </div>
            </div>

          </div>
        </main>
      )}

      {/* ลิขสิทธิ์เว็บส่วนท้าย (Footer) */}
      <footer className="border-t border-purple-900/20 bg-slate-950/90 py-6 px-6 text-center text-[11px] md:text-xs text-gray-500">
        <div className="max-w-7xl mx-auto flex flex-col md:flex-row justify-between items-center gap-4">
          <div>
            © 2026 NEXUS ESPORTS Recruitment. ระบบจับความเคลื่อนไหวพิกัด AR และฟังก์ชันสมัครงานลื่นไหลสมบูรณ์แบบ
          </div>
          <div className="flex gap-4">
            <span className="text-cyan-400 font-semibold">PHP + MySQL XAMPP Version Ready (database.sql / index.php)</span>
          </div>
        </div>
      </footer>

    </div>
  );
}
