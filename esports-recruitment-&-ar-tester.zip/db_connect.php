<?php
/**
 * ไฟล์เชื่อมต่อฐานข้อมูล MySQL (PDO)
 * สำหรับรันบน XAMPP (Host: localhost, User: root, Password: "")
 */

$host = "localhost";
$db_name = "esports_db";
$username = "root";
$password = ""; // รหัสผ่านว่างเป็นค่าเริ่มต้นของ XAMPP

try {
    // เชื่อมต่อฐานข้อมูลโดยกำหนดชุดอักขระเป็น utf8mb4
    $conn = new PDO("mysql:host=$host;dbname=$db_name;charset=utf8mb4", $username, $password);
    
    // ตั้งค่า Error Mode ให้แสดง Exception เมื่อเกิดข้อผิดพลาดในการรัน SQL
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    
    // ปิดการทำงานจำลองคำสั่งแบบเตรียมการ (Emulate Prepared Statements) เพื่อความปลอดภัยสูงสุดจาก SQL Injection
    $conn->setAttribute(PDO::ATTR_EMULATE_PREPARES, false);
    
} catch (PDOException $e) {
    // กรณีเชื่อมต่อไม่ได้ ให้แสดงข้อผิดพลาดและหยุดทำงาน
    die("เกิดข้อผิดพลาดในการเชื่อมต่อฐานข้อมูล: " . $e->getMessage());
}
?>
